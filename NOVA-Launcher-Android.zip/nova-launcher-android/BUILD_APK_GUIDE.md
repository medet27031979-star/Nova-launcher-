# Nova Launcher — Android APK Build & Release Guide

## 1. Environment Prerequisites
- **Android Studio**: Ladybug (2024.2.1) or newer
- **JDK**: 17 (Temurin or Android Studio embedded JBR 17)
- **Android SDK**: Platform 35 (`compileSdk = 35`, `minSdk = 29` / Android 10+)
- **Android NDK**: `27.1.12297006` (side-by-side via SDK Manager)
- **CMake**: `3.22.1` (via SDK Manager)
- **Target ABI**: `arm64-v8a` (Snapdragon / MediaTek 64-bit devices)

## 2. Building the Debug APK
From the `nova-launcher-android/` directory:

```bash
# Ensure Gradle wrapper is initialized (if opening in Android Studio, IDE syncs automatically)
gradle wrapper --gradle-version 8.9

# Build the ARM64 Debug APK
./gradlew :app:assembleDebug
```

Output path:
`app/build/outputs/apk/debug/app-debug.apk`

Install onto a connected Android 10+ ARM64 device via ADB:
```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## 3. Building a Signed Release APK
1. Generate a signing keystore (keep this private and outside Git):
```bash
keytool -genkeypair -v \
  -keystore nova-release.jks \
  -alias nova_key \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000
```

2. Add signing configuration in `app/build.gradle.kts` (reading passwords from environment variables or `keystore.properties`):
```kotlin
signingConfigs {
    create("release") {
        storeFile = file(System.getenv("NOVA_KEYSTORE_PATH") ?: "nova-release.jks")
        storePassword = System.getenv("NOVA_KEYSTORE_PASS")
        keyAlias = System.getenv("NOVA_KEY_ALIAS") ?: "nova_key"
        keyPassword = System.getenv("NOVA_KEY_PASS")
    }
}
```
And assign `signingConfig = signingConfigs.getByName("release")` inside `buildTypes.release`.

3. Build the minified, resource-shrunk Release APK:
```bash
./gradlew :app:assembleRelease
```

Output path:
`app/build/outputs/apk/release/app-release.apk`

4. Verify APK signature and ABI alignment:
```bash
apksigner verify --verbose app/build/outputs/apk/release/app-release.apk
```

## 4. Bundling ARM64 Java Runtimes
Nova Launcher manages modular ARM64 JRE packages (JRE 8, JRE 17, JRE 21) in `context.filesDir/runtimes/<runtimeId>/`.
At runtime, `JavaRuntimeManager` validates `bin/java` and `lib/aarch64/server/libjvm.so` (or `lib/server/libjvm.so` on JRE 17/21), enforces `0755` executable permissions, and passes the JVM path to the native `dlopen` launcher bridge.
