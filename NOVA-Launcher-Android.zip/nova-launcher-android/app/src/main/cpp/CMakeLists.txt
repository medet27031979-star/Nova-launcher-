cmake_minimum_required(VERSION 3.22.1)
project(nova_native LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

add_library(nova_native SHARED
    memory_pool.cpp
    hardware_probe.cpp
    gles_backend.cpp
    vulkan_backend.cpp
    nova_jni.cpp
)

target_include_directories(nova_native PRIVATE
    ${CMAKE_CURRENT_SOURCE_DIR}
)

target_compile_definitions(nova_native PRIVATE
    VK_USE_PLATFORM_ANDROID_KHR
    NOVA_ARM64_BUILD=1
)

target_compile_options(nova_native PRIVATE
    -O3
    -ffunction-sections
    -fdata-sections
    -Wall
    -Wextra
)

find_library(log-lib log)
find_library(android-lib android)
find_library(egl-lib EGL)
find_library(glesv3-lib GLESv3)

target_link_libraries(nova_native
    ${android-lib}
    ${log-lib}
    ${egl-lib}
    ${glesv3-lib}
    dl
)
