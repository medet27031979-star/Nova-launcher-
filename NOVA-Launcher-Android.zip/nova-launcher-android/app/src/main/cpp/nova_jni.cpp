#include "nova_common.h"
#include "memory_pool.h"

#include <android/native_window_jni.h>
#include <algorithm>
#include <chrono>
#include <dlfcn.h>
#include <jni.h>
#include <memory>
#include <mutex>
#include <thread>
#include <vector>

namespace {

struct EngineState {
    std::mutex lock;
    ANativeWindow* window = nullptr;
    std::unique_ptr<nova::IRenderBackend> backend;
    nova::FrameArenaPool framePool{4 * 1024 * 1024}; // 4 MB aligned scratch pool
    nova::FrameTelemetry telemetry;
    int32_t fpsLimit = 60;
    bool vsync = true;
    float resolutionScale = 1.0f;
    int32_t surfaceWidth = 1280;
    int32_t surfaceHeight = 720;
    std::chrono::steady_clock::time_point lastFrameTime = std::chrono::steady_clock::now();
};

EngineState g_engine;

using JniCreateJavaVM = jint (*)(JavaVM**, void**, void*);

} // namespace

extern "C" {

JNIEXPORT jobject JNICALL
Java_com_novalauncher_nativebridge_NovaNativeEngine_nativeProbeHardware(JNIEnv* env, jobject) {
    const nova::HardwareCapabilities caps = nova::probeDeviceHardware();

    jclass cls = env->FindClass("com/novalauncher/nativebridge/NativeHardwareInfo");
    if (!cls) return nullptr;

    jmethodID ctor = env->GetMethodID(
        cls,
        "<init>",
        "(IIJJLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZZLjava/lang/String;ILjava/lang/String;)V"
    );
    if (!ctor) return nullptr;

    jstring jSoc = env->NewStringUTF(caps.socHardware.c_str());
    jstring jVendor = env->NewStringUTF(caps.glesVendor.c_str());
    jstring jRenderer = env->NewStringUTF(caps.glesRenderer.c_str());
    jstring jVersion = env->NewStringUTF(caps.glesVersion.c_str());
    jstring jVkDevice = env->NewStringUTF(caps.vulkanDeviceName.c_str());
    jstring jReason = env->NewStringUTF(caps.recommendationReason.c_str());

    return env->NewObject(
        cls,
        ctor,
        caps.cpuCoreCount,
        caps.performanceCoreCount,
        static_cast<jlong>(caps.totalRamMb),
        static_cast<jlong>(caps.availableRamMb),
        jSoc,
        jVendor,
        jRenderer,
        jVersion,
        static_cast<jboolean>(caps.gles32Supported),
        static_cast<jboolean>(caps.vulkanInstanceVerified),
        static_cast<jboolean>(caps.vulkanAndroidSurfaceSupported),
        jVkDevice,
        static_cast<jint>(caps.recommendedBackend),
        jReason
    );
}

JNIEXPORT jboolean JNICALL
Java_com_novalauncher_nativebridge_NovaNativeEngine_nativeInitRenderer(
    JNIEnv* env,
    jobject,
    jobject surface,
    jint backendOrdinal,
    jint width,
    jint height,
    jfloat resolutionScale,
    jboolean vsync,
    jint fpsLimit
) {
    std::lock_guard<std::mutex> guard(g_engine.lock);
    if (g_engine.backend) {
        g_engine.backend->shutdown();
        g_engine.backend.reset();
    }
    if (g_engine.window) {
        ANativeWindow_release(g_engine.window);
        g_engine.window = nullptr;
    }

    g_engine.window = ANativeWindow_fromSurface(env, surface);
    if (!g_engine.window) return JNI_FALSE;

    g_engine.surfaceWidth = std::max(1, width);
    g_engine.surfaceHeight = std::max(1, height);
    g_engine.resolutionScale = std::clamp(resolutionScale, 0.5f, 1.0f);
    g_engine.vsync = (vsync == JNI_TRUE);
    g_engine.fpsLimit = std::max(15, fpsLimit);

    const int32_t scaledW = std::max(320, static_cast<int32_t>(g_engine.surfaceWidth * g_engine.resolutionScale));
    const int32_t scaledH = std::max(180, static_cast<int32_t>(g_engine.surfaceHeight * g_engine.resolutionScale));

    if (backendOrdinal == static_cast<int32_t>(nova::RendererBackend::VULKAN_1_1)) {
        std::unique_ptr<nova::IRenderBackend> vk(nova::createVulkanBackend());
        if (vk->initialize(g_engine.window, scaledW, scaledH, g_engine.vsync)) {
            g_engine.backend = std::move(vk);
        } else {
            NOVA_LOGW("Vulkan init failed on surface; falling back to OpenGL ES 3.2");
        }
    }

    if (!g_engine.backend) {
        std::unique_ptr<nova::IRenderBackend> gles(nova::createGlesBackend());
        if (!gles->initialize(g_engine.window, scaledW, scaledH, g_engine.vsync)) {
            ANativeWindow_release(g_engine.window);
            g_engine.window = nullptr;
            return JNI_FALSE;
        }
        g_engine.backend = std::move(gles);
    }

    g_engine.telemetry.activeWidth = scaledW;
    g_engine.telemetry.activeHeight = scaledH;
    g_engine.telemetry.activeBackend = g_engine.backend->type();
    g_engine.telemetry.poolCapacityBytes = g_engine.framePool.capacityBytes();
    g_engine.lastFrameTime = std::chrono::steady_clock::now();
    return JNI_TRUE;
}

JNIEXPORT void JNICALL
Java_com_novalauncher_nativebridge_NovaNativeEngine_nativeResizeSurface(JNIEnv*, jobject, jint width, jint height) {
    std::lock_guard<std::mutex> guard(g_engine.lock);
    g_engine.surfaceWidth = std::max(1, width);
    g_engine.surfaceHeight = std::max(1, height);
    if (!g_engine.backend) return;

    const int32_t scaledW = std::max(320, static_cast<int32_t>(g_engine.surfaceWidth * g_engine.resolutionScale));
    const int32_t scaledH = std::max(180, static_cast<int32_t>(g_engine.surfaceHeight * g_engine.resolutionScale));
    g_engine.backend->resize(scaledW, scaledH);
    g_engine.telemetry.activeWidth = scaledW;
    g_engine.telemetry.activeHeight = scaledH;
}

JNIEXPORT void JNICALL
Java_com_novalauncher_nativebridge_NovaNativeEngine_nativeSetFpsLimit(JNIEnv*, jobject, jint fpsLimit) {
    std::lock_guard<std::mutex> guard(g_engine.lock);
    g_engine.fpsLimit = std::max(15, fpsLimit);
}

JNIEXPORT void JNICALL
Java_com_novalauncher_nativebridge_NovaNativeEngine_nativeSetVSync(JNIEnv*, jobject, jboolean enabled) {
    std::lock_guard<std::mutex> guard(g_engine.lock);
    g_engine.vsync = (enabled == JNI_TRUE);
    if (g_engine.backend) {
        g_engine.backend->setVSync(g_engine.vsync);
    }
}

JNIEXPORT void JNICALL
Java_com_novalauncher_nativebridge_NovaNativeEngine_nativeSetResolutionScale(JNIEnv*, jobject, jfloat scale) {
    std::lock_guard<std::mutex> guard(g_engine.lock);
    g_engine.resolutionScale = std::clamp(scale, 0.5f, 1.0f);
    if (g_engine.backend) {
        const int32_t scaledW = std::max(320, static_cast<int32_t>(g_engine.surfaceWidth * g_engine.resolutionScale));
        const int32_t scaledH = std::max(180, static_cast<int32_t>(g_engine.surfaceHeight * g_engine.resolutionScale));
        g_engine.backend->resize(scaledW, scaledH);
        g_engine.telemetry.activeWidth = scaledW;
        g_engine.telemetry.activeHeight = scaledH;
    }
}

JNIEXPORT jboolean JNICALL
Java_com_novalauncher_nativebridge_NovaNativeEngine_nativeRenderFrame(JNIEnv*, jobject) {
    std::lock_guard<std::mutex> guard(g_engine.lock);
    if (!g_engine.backend) return JNI_FALSE;

    g_engine.framePool.resetFrame();
    void* scratch = g_engine.framePool.allocateAligned(64 * 1024, 64);
    (void)scratch;

    const bool ok = g_engine.backend->renderFrame(0.043f, 0.059f, 0.078f);

    const auto now = std::chrono::steady_clock::now();
    const double targetFrameMs = 1000.0 / static_cast<double>(g_engine.fpsLimit);
    double elapsedMs = std::chrono::duration<double, std::milli>(now - g_engine.lastFrameTime).count();
    if (!g_engine.vsync && elapsedMs < targetFrameMs) {
        const auto sleepUs = static_cast<int64_t>((targetFrameMs - elapsedMs) * 1000.0);
        if (sleepUs > 100) {
            std::this_thread::sleep_for(std::chrono::microseconds(sleepUs));
        }
    }

    const auto afterPace = std::chrono::steady_clock::now();
    const double totalMs = std::max(0.1, std::chrono::duration<double, std::milli>(afterPace - g_engine.lastFrameTime).count());
    g_engine.lastFrameTime = afterPace;

    g_engine.telemetry.frameTimeMs = totalMs;
    g_engine.telemetry.avgFrameTimeMs = g_engine.telemetry.renderedFrames == 0
        ? totalMs
        : (g_engine.telemetry.avgFrameTimeMs * 0.9 + totalMs * 0.1);
    g_engine.telemetry.currentFps = 1000.0 / g_engine.telemetry.avgFrameTimeMs;
    g_engine.telemetry.renderedFrames++;
    g_engine.telemetry.poolAllocatedBytes = g_engine.framePool.usedBytes();

    return ok ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jobject JNICALL
Java_com_novalauncher_nativebridge_NovaNativeEngine_nativeGetTelemetry(JNIEnv* env, jobject) {
    std::lock_guard<std::mutex> guard(g_engine.lock);
    jclass cls = env->FindClass("com/novalauncher/nativebridge/NativeTelemetry");
    if (!cls) return nullptr;

    jmethodID ctor = env->GetMethodID(cls, "<init>", "(DDDIIJJI)V");
    if (!ctor) return nullptr;

    return env->NewObject(
        cls,
        ctor,
        g_engine.telemetry.currentFps,
        g_engine.telemetry.frameTimeMs,
        g_engine.telemetry.avgFrameTimeMs,
        g_engine.telemetry.activeWidth,
        g_engine.telemetry.activeHeight,
        static_cast<jlong>(g_engine.telemetry.renderedFrames),
        static_cast<jlong>(g_engine.telemetry.poolAllocatedBytes),
        static_cast<jint>(g_engine.telemetry.activeBackend)
    );
}

JNIEXPORT void JNICALL
Java_com_novalauncher_nativebridge_NovaNativeEngine_nativeDestroyRenderer(JNIEnv*, jobject) {
    std::lock_guard<std::mutex> guard(g_engine.lock);
    if (g_engine.backend) {
        g_engine.backend->shutdown();
        g_engine.backend.reset();
    }
    if (g_engine.window) {
        ANativeWindow_release(g_engine.window);
        g_engine.window = nullptr;
    }
}

JNIEXPORT jint JNICALL
Java_com_novalauncher_nativebridge_NovaNativeEngine_nativeLaunchJvm(
    JNIEnv* env,
    jobject,
    jstring jLibJvmPath,
    jobjectArray jJvmArgs,
    jstring jMainClass,
    jobjectArray jGameArgs
) {
    const char* libPath = env->GetStringUTFChars(jLibJvmPath, nullptr);
    const char* mainClassName = env->GetStringUTFChars(jMainClass, nullptr);

    void* jvmLib = dlopen(libPath, RTLD_NOW | RTLD_GLOBAL);
    env->ReleaseStringUTFChars(jLibJvmPath, libPath);

    if (!jvmLib) {
        NOVA_LOGE("Failed to dlopen libjvm.so: %s", dlerror());
        env->ReleaseStringUTFChars(jMainClass, mainClassName);
        return -10;
    }

    auto createJavaVM = reinterpret_cast<JniCreateJavaVM>(dlsym(jvmLib, "JNI_CreateJavaVM"));
    if (!createJavaVM) {
        NOVA_LOGE("JNI_CreateJavaVM symbol not found in libjvm.so");
        env->ReleaseStringUTFChars(jMainClass, mainClassName);
        dlclose(jvmLib);
        return -11;
    }

    const jsize jvmArgCount = env->GetArrayLength(jJvmArgs);
    std::vector<std::string> optionStrings;
    optionStrings.reserve(static_cast<size_t>(jvmArgCount));
    for (jsize i = 0; i < jvmArgCount; ++i) {
        auto sObj = static_cast<jstring>(env->GetObjectArrayElement(jJvmArgs, i));
        const char* utf = env->GetStringUTFChars(sObj, nullptr);
        optionStrings.emplace_back(utf);
        env->ReleaseStringUTFChars(sObj, utf);
        env->DeleteLocalRef(sObj);
    }

    std::vector<JavaVMOption> options(optionStrings.size());
    for (size_t i = 0; i < optionStrings.size(); ++i) {
        options[i].optionString = const_cast<char*>(optionStrings[i].c_str());
        options[i].extraInfo = nullptr;
    }

    JavaVMInitArgs vmArgs{};
    vmArgs.version = JNI_VERSION_1_8;
    vmArgs.nOptions = static_cast<jint>(options.size());
    vmArgs.options = options.data();
    vmArgs.ignoreUnrecognized = JNI_TRUE;

    JavaVM* targetVm = nullptr;
    JNIEnv* targetEnv = nullptr;
    const jint vmStatus = createJavaVM(&targetVm, reinterpret_cast<void**>(&targetEnv), &vmArgs);
    if (vmStatus != JNI_OK || !targetEnv) {
        NOVA_LOGE("JNI_CreateJavaVM failed with code %d", vmStatus);
        env->ReleaseStringUTFChars(jMainClass, mainClassName);
        dlclose(jvmLib);
        return vmStatus;
    }

    jclass mainCls = targetEnv->FindClass(mainClassName);
    env->ReleaseStringUTFChars(jMainClass, mainClassName);
    if (!mainCls) {
        NOVA_LOGE("Target Minecraft main class not found on classpath");
        targetVm->DestroyJavaVM();
        dlclose(jvmLib);
        return -12;
    }

    jmethodID mainMethod = targetEnv->GetStaticMethodID(mainCls, "main", "([Ljava/lang/String;)V");
    if (!mainMethod) {
        NOVA_LOGE("public static void main(String[]) not found");
        targetVm->DestroyJavaVM();
        dlclose(jvmLib);
        return -13;
    }

    const jsize gameArgCount = env->GetArrayLength(jGameArgs);
    jclass strCls = targetEnv->FindClass("java/lang/String");
    jobjectArray targetArgs = targetEnv->NewObjectArray(gameArgCount, strCls, nullptr);
    for (jsize i = 0; i < gameArgCount; ++i) {
        auto sObj = static_cast<jstring>(env->GetObjectArrayElement(jGameArgs, i));
        const char* utf = env->GetStringUTFChars(sObj, nullptr);
        jstring targetStr = targetEnv->NewStringUTF(utf);
        targetEnv->SetObjectArrayElement(targetArgs, i, targetStr);
        targetEnv->DeleteLocalRef(targetStr);
        env->ReleaseStringUTFChars(sObj, utf);
        env->DeleteLocalRef(sObj);
    }

    targetEnv->CallStaticVoidMethod(mainCls, mainMethod, targetArgs);
    jint exitCode = targetEnv->ExceptionCheck() ? -14 : 0;
    if (exitCode != 0) {
        targetEnv->ExceptionDescribe();
        targetEnv->ExceptionClear();
    }

    targetVm->DestroyJavaVM();
    dlclose(jvmLib);
    return exitCode;
}

} // extern "C"
