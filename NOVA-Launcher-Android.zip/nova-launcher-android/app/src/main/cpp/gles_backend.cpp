#include "nova_common.h"

#include <EGL/egl.h>
#include <GLES3/gl32.h>

namespace nova {

class GlesRenderBackend final : public IRenderBackend {
public:
    ~GlesRenderBackend() override { shutdown(); }

    bool initialize(ANativeWindow* window, int32_t width, int32_t height, bool vsync) override {
        if (!window) return false;
        window_ = window;

        display_ = eglGetDisplay(EGL_DEFAULT_DISPLAY);
        if (display_ == EGL_NO_DISPLAY) return false;
        if (!eglInitialize(display_, nullptr, nullptr)) return false;

        const EGLint configAttribs[] = {
            EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT,
            EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
            EGL_RED_SIZE, 8,
            EGL_GREEN_SIZE, 8,
            EGL_BLUE_SIZE, 8,
            EGL_ALPHA_SIZE, 8,
            EGL_DEPTH_SIZE, 24,
            EGL_STENCIL_SIZE, 8,
            EGL_NONE
        };
        EGLint numConfigs = 0;
        if (!eglChooseConfig(display_, configAttribs, &config_, 1, &numConfigs) || numConfigs <= 0) {
            shutdown();
            return false;
        }

        EGLint visualId = 0;
        eglGetConfigAttrib(display_, config_, EGL_NATIVE_VISUAL_ID, &visualId);
        ANativeWindow_setBuffersGeometry(window_, width, height, visualId);

        const EGLint contextAttribs[] = {
            EGL_CONTEXT_CLIENT_VERSION, 3,
            EGL_NONE
        };
        context_ = eglCreateContext(display_, config_, EGL_NO_CONTEXT, contextAttribs);
        if (context_ == EGL_NO_CONTEXT) {
            shutdown();
            return false;
        }

        surface_ = eglCreateWindowSurface(display_, config_, window_, nullptr);
        if (surface_ == EGL_NO_SURFACE) {
            shutdown();
            return false;
        }

        if (!eglMakeCurrent(display_, surface_, surface_, context_)) {
            shutdown();
            return false;
        }

        width_ = width;
        height_ = height;
        setVSync(vsync);
        glViewport(0, 0, width_, height_);
        NOVA_LOGI("GLES3.2 backend initialized (%dx%d, vsync=%d)", width_, height_, vsync ? 1 : 0);
        return true;
    }

    bool resize(int32_t width, int32_t height) override {
        if (display_ == EGL_NO_DISPLAY || !window_) return false;
        width_ = width;
        height_ = height;
        EGLint visualId = 0;
        eglGetConfigAttrib(display_, config_, EGL_NATIVE_VISUAL_ID, &visualId);
        ANativeWindow_setBuffersGeometry(window_, width_, height_, visualId);
        glViewport(0, 0, width_, height_);
        return true;
    }

    void setVSync(bool enabled) override {
        if (display_ != EGL_NO_DISPLAY) {
            eglSwapInterval(display_, enabled ? 1 : 0);
        }
    }

    bool renderFrame(float clearR, float clearG, float clearB) override {
        if (display_ == EGL_NO_DISPLAY || surface_ == EGL_NO_SURFACE) return false;
        glClearColor(clearR, clearG, clearB, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        return eglSwapBuffers(display_, surface_) == EGL_TRUE;
    }

    void shutdown() override {
        if (display_ != EGL_NO_DISPLAY) {
            eglMakeCurrent(display_, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
            if (surface_ != EGL_NO_SURFACE) {
                eglDestroySurface(display_, surface_);
                surface_ = EGL_NO_SURFACE;
            }
            if (context_ != EGL_NO_CONTEXT) {
                eglDestroyContext(display_, context_);
                context_ = EGL_NO_CONTEXT;
            }
            eglTerminate(display_);
            display_ = EGL_NO_DISPLAY;
        }
        window_ = nullptr;
    }

    RendererBackend type() const override { return RendererBackend::OPENGL_ES_32; }

private:
    ANativeWindow* window_ = nullptr;
    EGLDisplay display_ = EGL_NO_DISPLAY;
    EGLConfig config_ = nullptr;
    EGLContext context_ = EGL_NO_CONTEXT;
    EGLSurface surface_ = EGL_NO_SURFACE;
    int32_t width_ = 0;
    int32_t height_ = 0;
};

IRenderBackend* createGlesBackend() {
    return new GlesRenderBackend();
}

} // namespace nova
