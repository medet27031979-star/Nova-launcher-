#include "memory_pool.h"
#include "nova_common.h"

#include <cstdlib>
#include <fstream>
#include <sstream>
#include <string>
#include <sys/sysinfo.h>

namespace nova {

FrameArenaPool::FrameArenaPool(size_t capacityBytes) : capacity_(capacityBytes) {
    if (capacity_ > 0) {
        buffer_ = static_cast<uint8_t*>(std::aligned_alloc(64, capacity_));
        if (!buffer_) {
            NOVA_LOGE("Failed to reserve %zu bytes for FrameArenaPool", capacity_);
            capacity_ = 0;
        }
    }
}

FrameArenaPool::~FrameArenaPool() {
    if (buffer_) {
        std::free(buffer_);
        buffer_ = nullptr;
    }
}

void* FrameArenaPool::allocateAligned(size_t bytes, size_t alignment) {
    if (!buffer_ || bytes == 0) {
        return nullptr;
    }
    const size_t mask = alignment - 1;
    size_t current = offset_.load(std::memory_order_relaxed);
    while (true) {
        const size_t aligned = (current + mask) & ~mask;
        const size_t next = aligned + bytes;
        if (next > capacity_) {
            return nullptr;
        }
        if (offset_.compare_exchange_weak(current, next, std::memory_order_acq_rel)) {
            return buffer_ + aligned;
        }
    }
}

void FrameArenaPool::resetFrame() {
    offset_.store(0, std::memory_order_release);
}

size_t FrameArenaPool::usedBytes() const {
    return offset_.load(std::memory_order_acquire);
}

SystemMemorySnapshot querySystemMemory() {
    SystemMemorySnapshot snap;
    struct sysinfo info {};
    if (sysinfo(&info) == 0) {
        const uint64_t unit = info.mem_unit ? info.mem_unit : 1;
        snap.totalRamMb = static_cast<int64_t>((static_cast<uint64_t>(info.totalram) * unit) / (1024ULL * 1024ULL));
        snap.freeRamMb = static_cast<int64_t>((static_cast<uint64_t>(info.freeram) * unit) / (1024ULL * 1024ULL));
    }

    std::ifstream meminfo("/proc/meminfo");
    if (meminfo.is_open()) {
        std::string line;
        while (std::getline(meminfo, line)) {
            if (line.rfind("MemAvailable:", 0) == 0) {
                std::istringstream iss(line.substr(13));
                int64_t kb = 0;
                iss >> kb;
                snap.availableRamMb = kb / 1024;
                break;
            }
        }
    }

    if (snap.availableRamMb == 0) {
        snap.availableRamMb = snap.freeRamMb;
    }
    return snap;
}

} // namespace nova
