#pragma once

#include <android/log.h>
#include <android/native_window.h>
#include <cstdint>
#include <string>

#define NOVA_LOG_TAG "NovaNative"
#define NOVA_LOGI(...) __android_log_print(ANDROID_LOG_INFO, NOVA_LOG_TAG, __VA_ARGS__)
#define NOVA_LOGW(...) __android_log_print(ANDROID_LOG_WARN, NOVA_LOG_TAG, __VA_ARGS__)
#define NOVA_LOGE(...) __android_log_print(ANDROID_LOG_ERROR, NOVA_LOG_TAG, __VA_ARGS__)

namespace nova {

enum class RendererBackend : int32_t {
    OPENGL_ES_32 = 0,
    VULKAN_1_1 = 1
};

enum class GpuVendor : int32_t {
    UNKNOWN = 0,
    QUALCOMM_ADRENO = 1,
    ARM_MALI = 2,
    POWERVR = 3
};

struct HardwareCapabilities {
    int32_t cpuCoreCount = 0;
    int32_t performanceCoreCount = 0;
    int64_t totalRamMb = 0;
    int64_t availableRamMb = 0;
    std::string socHardware;
    std::string cpuArchitecture;
    std::string glesVendor;
    std::string glesRenderer;
    std::string glesVersion;
    GpuVendor gpuVendor = GpuVendor::UNKNOWN;
    bool gles32Supported = false;
    bool vulkanLoaderPresent = false;
    bool vulkanInstanceVerified = false;
    bool vulkanAndroidSurfaceSupported = false;
    uint32_t vulkanApiVersion = 0;
    std::string vulkanDeviceName;
    RendererBackend recommendedBackend = RendererBackend::OPENGL_ES_32;
    std::string recommendationReason;
};

struct FrameTelemetry {
    double currentFps = 0.0;
    double frameTimeMs = 0.0;
    double avgFrameTimeMs = 0.0;
    uint64_t renderedFrames = 0;
    uint64_t poolAllocatedBytes = 0;
    uint64_t poolCapacityBytes = 0;
    int32_t activeWidth = 0;
    int32_t activeHeight = 0;
    RendererBackend activeBackend = RendererBackend::OPENGL_ES_32;
};

class IRenderBackend {
public:
    virtual ~IRenderBackend() = default;
    virtual bool initialize(ANativeWindow* window, int32_t width, int32_t height, bool vsync) = 0;
    virtual bool resize(int32_t width, int32_t height) = 0;
    virtual void setVSync(bool enabled) = 0;
    virtual bool renderFrame(float clearR, float clearG, float clearB) = 0;
    virtual void shutdown() = 0;
    virtual RendererBackend type() const = 0;
};

HardwareCapabilities probeDeviceHardware();
IRenderBackend* createGlesBackend();
IRenderBackend* createVulkanBackend();

} // namespace nova
