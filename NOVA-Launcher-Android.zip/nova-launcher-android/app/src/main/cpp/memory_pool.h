#pragma once

#include <atomic>
#include <cstddef>
#include <cstdint>

namespace nova {

/**
 * Fixed-capacity lock-free linear arena & slab allocator for frame-critical
 * native buffers so render loops avoid heap fragmentation on 4GB Android devices.
 */
class FrameArenaPool {
public:
    explicit FrameArenaPool(size_t capacityBytes);
    ~FrameArenaPool();

    FrameArenaPool(const FrameArenaPool&) = delete;
    FrameArenaPool& operator=(const FrameArenaPool&) = delete;

    void* allocateAligned(size_t bytes, size_t alignment = 16);
    void resetFrame();

    size_t usedBytes() const;
    size_t capacityBytes() const { return capacity_; }

private:
    uint8_t* buffer_ = nullptr;
    size_t capacity_ = 0;
    std::atomic<size_t> offset_{0};
};

struct SystemMemorySnapshot {
    int64_t totalRamMb = 0;
    int64_t freeRamMb = 0;
    int64_t availableRamMb = 0;
};

SystemMemorySnapshot querySystemMemory();

} // namespace nova
