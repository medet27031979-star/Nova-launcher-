#include "nova_common.h"
#include "memory_pool.h"

#include <EGL/egl.h>
#include <GLES3/gl32.h>
#include <algorithm>
#include <cctype>
#include <cstring>
#include <dlfcn.h>
#include <fstream>
#include <sstream>
#include <unistd.h>
#include <vector>
#include <vulkan/vulkan.h>

namespace nova {

namespace {

std::string toLower(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) {
        return static_cast<char>(std::tolower(c));
    });
    return s;
}

void detectCpuTopology(HardwareCapabilities& caps) {
    caps.cpuCoreCount = static_cast<int32_t>(sysconf(_SC_NPROCESSORS_CONF));
    caps.cpuArchitecture = "arm64-v8a";

    int32_t maxFreqKhz = 0;
    std::vector<int32_t> coreFreqs;
    for (int32_t i = 0; i < caps.cpuCoreCount && i < 16; ++i) {
        std::string path = "/sys/devices/system/cpu/cpu" + std::to_string(i) + "/cpufreq/cpuinfo_max_freq";
        std::ifstream f(path);
        int32_t freq = 0;
        if (f >> freq) {
            coreFreqs.push_back(freq);
            if (freq > maxFreqKhz) {
                maxFreqKhz = freq;
            }
        }
    }

    int32_t bigCores = 0;
    for (int32_t freq : coreFreqs) {
        if (maxFreqKhz > 0 && freq >= (maxFreqKhz * 75) / 100) {
            ++bigCores;
        }
    }
    caps.performanceCoreCount = bigCores > 0 ? bigCores : std::max(1, caps.cpuCoreCount / 2);

    std::ifstream cpuinfo("/proc/cpuinfo");
    if (cpuinfo.is_open()) {
        std::string line;
        while (std::getline(cpuinfo, line)) {
            if (line.rfind("Hardware", 0) == 0) {
                auto pos = line.find(':');
                if (pos != std::string::npos) {
                    caps.socHardware = line.substr(pos + 1);
                    size_t first = caps.socHardware.find_first_not_of(" \t");
                    if (first != std::string::npos) {
                        caps.socHardware = caps.socHardware.substr(first);
                    }
                }
            }
        }
    }
    if (caps.socHardware.empty()) {
        caps.socHardware = "ARM64 SoC";
    }
}

void probeOpenGlEs(HardwareCapabilities& caps) {
    EGLDisplay display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (display == EGL_NO_DISPLAY) {
        return;
    }
    EGLint major = 0, minor = 0;
    if (!eglInitialize(display, &major, &minor)) {
        return;
    }

    const EGLint configAttribs[] = {
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT,
        EGL_SURFACE_TYPE, EGL_PBUFFER_BIT,
        EGL_RED_SIZE, 8,
        EGL_GREEN_SIZE, 8,
        EGL_BLUE_SIZE, 8,
        EGL_NONE
    };
    EGLConfig config = nullptr;
    EGLint numConfigs = 0;
    if (eglChooseConfig(display, configAttribs, &config, 1, &numConfigs) && numConfigs > 0) {
        const EGLint pbufferAttribs[] = { EGL_WIDTH, 16, EGL_HEIGHT, 16, EGL_NONE };
        EGLSurface surface = eglCreatePbufferSurface(display, config, pbufferAttribs);
        const EGLint ctxAttribs[] = { EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE };
        EGLContext ctx = eglCreateContext(display, config, EGL_NO_CONTEXT, ctxAttribs);
        if (surface != EGL_NO_SURFACE && ctx != EGL_NO_CONTEXT) {
            if (eglMakeCurrent(display, surface, surface, ctx)) {
                const char* vendor = reinterpret_cast<const char*>(glGetString(GL_VENDOR));
                const char* renderer = reinterpret_cast<const char*>(glGetString(GL_RENDERER));
                const char* version = reinterpret_cast<const char*>(glGetString(GL_VERSION));
                caps.glesVendor = vendor ? vendor : "Unknown";
                caps.glesRenderer = renderer ? renderer : "Unknown";
                caps.glesVersion = version ? version : "OpenGL ES 3.0";

                GLint glMajor = 0, glMinor = 0;
                glGetIntegerv(GL_MAJOR_VERSION, &glMajor);
                glGetIntegerv(GL_MINOR_VERSION, &glMinor);
                caps.gles32Supported = (glMajor > 3) || (glMajor == 3 && glMinor >= 2);

                const std::string rLower = toLower(caps.glesRenderer);
                const std::string vLower = toLower(caps.glesVendor);
                if (rLower.find("adreno") != std::string::npos || vLower.find("qualcomm") != std::string::npos) {
                    caps.gpuVendor = GpuVendor::QUALCOMM_ADRENO;
                } else if (rLower.find("mali") != std::string::npos || vLower.find("arm") != std::string::npos) {
                    caps.gpuVendor = GpuVendor::ARM_MALI;
                } else if (rLower.find("powervr") != std::string::npos || vLower.find("imagination") != std::string::npos) {
                    caps.gpuVendor = GpuVendor::POWERVR;
                }
            }
            eglMakeCurrent(display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        }
        if (ctx != EGL_NO_CONTEXT) eglDestroyContext(display, ctx);
        if (surface != EGL_NO_SURFACE) eglDestroySurface(display, surface);
    }
    eglTerminate(display);
}

void probeVulkanRuntime(HardwareCapabilities& caps) {
    void* vkLib = dlopen("libvulkan.so", RTLD_NOW | RTLD_LOCAL);
    if (!vkLib) {
        caps.vulkanLoaderPresent = false;
        return;
    }
    caps.vulkanLoaderPresent = true;

    auto pfnEnumerateExt = reinterpret_cast<PFN_vkEnumerateInstanceExtensionProperties>(
        dlsym(vkLib, "vkEnumerateInstanceExtensionProperties"));
    auto pfnCreateInstance = reinterpret_cast<PFN_vkCreateInstance>(
        dlsym(vkLib, "vkCreateInstance"));
    auto pfnDestroyInstance = reinterpret_cast<PFN_vkDestroyInstance>(
        dlsym(vkLib, "vkDestroyInstance"));
    auto pfnEnumDevices = reinterpret_cast<PFN_vkEnumeratePhysicalDevices>(
        dlsym(vkLib, "vkEnumeratePhysicalDevices"));
    auto pfnGetProps = reinterpret_cast<PFN_vkGetPhysicalDeviceProperties>(
        dlsym(vkLib, "vkGetPhysicalDeviceProperties"));
    auto pfnGetQueues = reinterpret_cast<PFN_vkGetPhysicalDeviceQueueFamilyProperties>(
        dlsym(vkLib, "vkGetPhysicalDeviceQueueFamilyProperties"));

    if (!pfnEnumerateExt || !pfnCreateInstance || !pfnDestroyInstance || !pfnEnumDevices || !pfnGetProps || !pfnGetQueues) {
        dlclose(vkLib);
        return;
    }

    uint32_t extCount = 0;
    pfnEnumerateExt(nullptr, &extCount, nullptr);
    std::vector<VkExtensionProperties> exts(extCount);
    if (extCount > 0) {
        pfnEnumerateExt(nullptr, &extCount, exts.data());
    }

    bool hasSurface = false;
    bool hasAndroidSurface = false;
    for (const auto& ext : exts) {
        if (std::strcmp(ext.extensionName, VK_KHR_SURFACE_EXTENSION_NAME) == 0) hasSurface = true;
        if (std::strcmp(ext.extensionName, VK_KHR_ANDROID_SURFACE_EXTENSION_NAME) == 0) hasAndroidSurface = true;
    }
    caps.vulkanAndroidSurfaceSupported = hasSurface && hasAndroidSurface;
    if (!caps.vulkanAndroidSurfaceSupported) {
        dlclose(vkLib);
        return;
    }

    const char* requiredExts[] = {
        VK_KHR_SURFACE_EXTENSION_NAME,
        VK_KHR_ANDROID_SURFACE_EXTENSION_NAME
    };
    VkApplicationInfo appInfo{};
    appInfo.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO;
    appInfo.pApplicationName = "NovaLauncherProbe";
    appInfo.applicationVersion = VK_MAKE_VERSION(1, 0, 0);
    appInfo.pEngineName = "NovaNative";
    appInfo.engineVersion = VK_MAKE_VERSION(1, 0, 0);
    appInfo.apiVersion = VK_API_VERSION_1_1;

    VkInstanceCreateInfo createInfo{};
    createInfo.sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;
    createInfo.pApplicationInfo = &appInfo;
    createInfo.enabledExtensionCount = 2;
    createInfo.ppEnabledExtensionNames = requiredExts;

    VkInstance instance = VK_NULL_HANDLE;
    if (pfnCreateInstance(&createInfo, nullptr, &instance) != VK_SUCCESS || instance == VK_NULL_HANDLE) {
        dlclose(vkLib);
        return;
    }

    uint32_t deviceCount = 0;
    pfnEnumDevices(instance, &deviceCount, nullptr);
    if (deviceCount > 0) {
        std::vector<VkPhysicalDevice> devices(deviceCount);
        if (pfnEnumDevices(instance, &deviceCount, devices.data()) == VK_SUCCESS) {
            for (VkPhysicalDevice dev : devices) {
                VkPhysicalDeviceProperties props{};
                pfnGetProps(dev, &props);

                uint32_t qCount = 0;
                pfnGetQueues(dev, &qCount, nullptr);
                std::vector<VkQueueFamilyProperties> queues(qCount);
                pfnGetQueues(dev, &qCount, queues.data());

                bool hasGraphicsQueue = false;
                for (const auto& q : queues) {
                    if (q.queueFlags & VK_QUEUE_GRAPHICS_BIT) {
                        hasGraphicsQueue = true;
                        break;
                    }
                }

                if (hasGraphicsQueue && props.apiVersion >= VK_API_VERSION_1_1) {
                    caps.vulkanInstanceVerified = true;
                    caps.vulkanApiVersion = props.apiVersion;
                    caps.vulkanDeviceName = props.deviceName;
                    break;
                }
            }
        }
    }

    pfnDestroyInstance(instance, nullptr);
    dlclose(vkLib);
}

} // namespace

HardwareCapabilities probeDeviceHardware() {
    HardwareCapabilities caps;
    const auto mem = querySystemMemory();
    caps.totalRamMb = mem.totalRamMb;
    caps.availableRamMb = mem.availableRamMb;

    detectCpuTopology(caps);
    probeOpenGlEs(caps);
    probeVulkanRuntime(caps);

    // Recommend Vulkan 1.1+ only when instance + Android surface + graphics queue verified
    // and GPU is modern Adreno or Mali with >= 4GB RAM; otherwise use OpenGL ES 3.2.
    if (caps.vulkanInstanceVerified && caps.vulkanAndroidSurfaceSupported &&
        caps.gpuVendor != GpuVendor::POWERVR && caps.totalRamMb >= 3800) {
        caps.recommendedBackend = RendererBackend::VULKAN_1_1;
        caps.recommendationReason = "Vulkan 1.1+ verified with VK_KHR_android_surface on " + caps.vulkanDeviceName;
    } else {
        caps.recommendedBackend = RendererBackend::OPENGL_ES_32;
        if (!caps.vulkanInstanceVerified) {
            caps.recommendationReason = "OpenGL ES selected: Vulkan 1.1 instance or Android surface extension unavailable";
        } else {
            caps.recommendationReason = "OpenGL ES 3.2 selected for driver stability and low-RAM overhead";
        }
    }

    NOVA_LOGI("Probe complete: GPU=%s VulkanVerified=%d RAM=%lldMB",
              caps.glesRenderer.c_str(),
              caps.vulkanInstanceVerified ? 1 : 0,
              static_cast<long long>(caps.totalRamMb));
    return caps;
}

} // namespace nova
