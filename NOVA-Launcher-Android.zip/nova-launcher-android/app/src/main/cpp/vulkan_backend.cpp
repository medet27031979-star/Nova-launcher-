#include "nova_common.h"

#include <algorithm>
#include <cstring>
#include <dlfcn.h>
#include <vector>
#include <vulkan/vulkan.h>
#include <vulkan/vulkan_android.h>

namespace nova {

/**
 * Real Vulkan 1.1+ Android Surface + Swapchain presentation backend.
 * Dynamically resolves libvulkan.so symbols so devices without a valid Vulkan ICD
 * safely fail initialization and let the orchestrator fall back to OpenGL ES 3.2.
 */
class VulkanRenderBackend final : public IRenderBackend {
public:
    ~VulkanRenderBackend() override { shutdown(); }

    bool initialize(ANativeWindow* window, int32_t width, int32_t height, bool vsync) override {
        if (!window) return false;
        window_ = window;
        vsync_ = vsync;

        vkLib_ = dlopen("libvulkan.so", RTLD_NOW | RTLD_LOCAL);
        if (!vkLib_) {
            NOVA_LOGW("Vulkan initialize failed: libvulkan.so not found");
            return false;
        }

        if (!loadGlobalSymbols()) {
            shutdown();
            return false;
        }

        const char* instanceExts[] = {
            VK_KHR_SURFACE_EXTENSION_NAME,
            VK_KHR_ANDROID_SURFACE_EXTENSION_NAME
        };

        VkApplicationInfo appInfo{};
        appInfo.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO;
        appInfo.pApplicationName = "NovaLauncher";
        appInfo.applicationVersion = VK_MAKE_VERSION(1, 0, 0);
        appInfo.pEngineName = "NovaVulkan";
        appInfo.engineVersion = VK_MAKE_VERSION(1, 0, 0);
        appInfo.apiVersion = VK_API_VERSION_1_1;

        VkInstanceCreateInfo ici{};
        ici.sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;
        ici.pApplicationInfo = &appInfo;
        ici.enabledExtensionCount = 2;
        ici.ppEnabledExtensionNames = instanceExts;

        if (vkCreateInstance_(&ici, nullptr, &instance_) != VK_SUCCESS) {
            shutdown();
            return false;
        }

        if (!loadInstanceSymbols()) {
            shutdown();
            return false;
        }

        VkAndroidSurfaceCreateInfoKHR sci{};
        sci.sType = VK_STRUCTURE_TYPE_ANDROID_SURFACE_CREATE_INFO_KHR;
        sci.window = window_;
        if (vkCreateAndroidSurfaceKHR_(instance_, &sci, nullptr, &surface_) != VK_SUCCESS) {
            shutdown();
            return false;
        }

        if (!selectPhysicalDevice() || !createLogicalDevice()) {
            shutdown();
            return false;
        }

        if (!createSwapchain(width, height) || !createSyncAndCommands()) {
            shutdown();
            return false;
        }

        NOVA_LOGI("Vulkan 1.1+ backend initialized (%dx%d, vsync=%d)", width, height, vsync ? 1 : 0);
        return true;
    }

    bool resize(int32_t width, int32_t height) override {
        if (device_ == VK_NULL_HANDLE) return false;
        vkDeviceWaitIdle_(device_);
        destroySwapchain();
        return createSwapchain(width, height);
    }

    void setVSync(bool enabled) override {
        if (vsync_ == enabled) return;
        vsync_ = enabled;
        if (device_ != VK_NULL_HANDLE && swapchainExtent_.width > 0) {
            resize(static_cast<int32_t>(swapchainExtent_.width),
                   static_cast<int32_t>(swapchainExtent_.height));
        }
    }

    bool renderFrame(float clearR, float clearG, float clearB) override {
        if (device_ == VK_NULL_HANDLE || swapchain_ == VK_NULL_HANDLE) return false;

        vkWaitForFences_(device_, 1, &inFlightFence_, VK_TRUE, UINT64_MAX);
        vkResetFences_(device_, 1, &inFlightFence_);

        uint32_t imageIndex = 0;
        VkResult acq = vkAcquireNextImageKHR_(device_, swapchain_, UINT64_MAX, imageAvailable_, VK_NULL_HANDLE, &imageIndex);
        if (acq == VK_ERROR_OUT_OF_DATE_KHR) {
            return true;
        } else if (acq != VK_SUCCESS && acq != VK_SUBOPTIMAL_KHR) {
            return false;
        }

        VkCommandBuffer cmd = commandBuffers_[imageIndex];
        vkResetCommandBuffer_(cmd, 0);

        VkCommandBufferBeginInfo beginInfo{};
        beginInfo.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO;
        vkBeginCommandBuffer_(cmd, &beginInfo);

        VkClearColorValue clearColor{{clearR, clearG, clearB, 1.0f}};
        VkImageSubresourceRange range{};
        range.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
        range.levelCount = 1;
        range.layerCount = 1;

        VkImageMemoryBarrier toTransfer{};
        toTransfer.sType = VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER;
        toTransfer.oldLayout = VK_IMAGE_LAYOUT_UNDEFINED;
        toTransfer.newLayout = VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL;
        toTransfer.srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
        toTransfer.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
        toTransfer.image = swapchainImages_[imageIndex];
        toTransfer.subresourceRange = range;
        toTransfer.dstAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;

        vkCmdPipelineBarrier_(cmd, VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT,
                              0, 0, nullptr, 0, nullptr, 1, &toTransfer);
        vkCmdClearColorImage_(cmd, swapchainImages_[imageIndex], VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
                              &clearColor, 1, &range);

        VkImageMemoryBarrier toPresent{};
        toPresent.sType = VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER;
        toPresent.oldLayout = VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL;
        toPresent.newLayout = VK_IMAGE_LAYOUT_PRESENT_SRC_KHR;
        toPresent.srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
        toPresent.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
        toPresent.image = swapchainImages_[imageIndex];
        toPresent.subresourceRange = range;
        toPresent.srcAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;

        vkCmdPipelineBarrier_(cmd, VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT,
                              0, 0, nullptr, 0, nullptr, 1, &toPresent);
        vkEndCommandBuffer_(cmd);

        VkPipelineStageFlags waitStage = VK_PIPELINE_STAGE_TRANSFER_BIT;
        VkSubmitInfo submitInfo{};
        submitInfo.sType = VK_STRUCTURE_TYPE_SUBMIT_INFO;
        submitInfo.waitSemaphoreCount = 1;
        submitInfo.pWaitSemaphores = &imageAvailable_;
        submitInfo.pWaitDstStageMask = &waitStage;
        submitInfo.commandBufferCount = 1;
        submitInfo.pCommandBuffers = &cmd;
        submitInfo.signalSemaphoreCount = 1;
        submitInfo.pSignalSemaphores = &renderFinished_;

        if (vkQueueSubmit_(graphicsQueue_, 1, &submitInfo, inFlightFence_) != VK_SUCCESS) {
            return false;
        }

        VkPresentInfoKHR presentInfo{};
        presentInfo.sType = VK_STRUCTURE_TYPE_PRESENT_INFO_KHR;
        presentInfo.waitSemaphoreCount = 1;
        presentInfo.pWaitSemaphores = &renderFinished_;
        presentInfo.swapchainCount = 1;
        presentInfo.pSwapchains = &swapchain_;
        presentInfo.pImageIndices = &imageIndex;

        VkResult pres = vkQueuePresentKHR_(graphicsQueue_, &presentInfo);
        return pres == VK_SUCCESS || pres == VK_SUBOPTIMAL_KHR;
    }

    void shutdown() override {
        if (device_ != VK_NULL_HANDLE && vkDeviceWaitIdle_) {
            vkDeviceWaitIdle_(device_);
        }
        destroySwapchain();
        if (device_ != VK_NULL_HANDLE) {
            if (imageAvailable_ != VK_NULL_HANDLE) vkDestroySemaphore_(device_, imageAvailable_, nullptr);
            if (renderFinished_ != VK_NULL_HANDLE) vkDestroySemaphore_(device_, renderFinished_, nullptr);
            if (inFlightFence_ != VK_NULL_HANDLE) vkDestroyFence_(device_, inFlightFence_, nullptr);
            if (commandPool_ != VK_NULL_HANDLE) vkDestroyCommandPool_(device_, commandPool_, nullptr);
            vkDestroyDevice_(device_, nullptr);
            device_ = VK_NULL_HANDLE;
        }
        if (instance_ != VK_NULL_HANDLE) {
            if (surface_ != VK_NULL_HANDLE) vkDestroySurfaceKHR_(instance_, surface_, nullptr);
            vkDestroyInstance_(instance_, nullptr);
            instance_ = VK_NULL_HANDLE;
        }
        if (vkLib_) {
            dlclose(vkLib_);
            vkLib_ = nullptr;
        }
        imageAvailable_ = VK_NULL_HANDLE;
        renderFinished_ = VK_NULL_HANDLE;
        inFlightFence_ = VK_NULL_HANDLE;
        commandPool_ = VK_NULL_HANDLE;
        surface_ = VK_NULL_HANDLE;
        window_ = nullptr;
    }

    RendererBackend type() const override { return RendererBackend::VULKAN_1_1; }

private:
    bool loadGlobalSymbols() {
        vkGetInstanceProcAddr_ = reinterpret_cast<PFN_vkGetInstanceProcAddr>(dlsym(vkLib_, "vkGetInstanceProcAddr"));
        vkCreateInstance_ = reinterpret_cast<PFN_vkCreateInstance>(dlsym(vkLib_, "vkCreateInstance"));
        return vkGetInstanceProcAddr_ && vkCreateInstance_;
    }

    bool loadInstanceSymbols() {
        #define LOAD_INST(fn) fn##_ = reinterpret_cast<PFN_##fn>(vkGetInstanceProcAddr_(instance_, #fn)); if (!fn##_) return false
        LOAD_INST(vkDestroyInstance);
        LOAD_INST(vkEnumeratePhysicalDevices);
        LOAD_INST(vkGetPhysicalDeviceQueueFamilyProperties);
        LOAD_INST(vkGetPhysicalDeviceSurfaceSupportKHR);
        LOAD_INST(vkGetPhysicalDeviceSurfaceCapabilitiesKHR);
        LOAD_INST(vkGetPhysicalDeviceSurfaceFormatsKHR);
        LOAD_INST(vkGetPhysicalDeviceSurfacePresentModesKHR);
        LOAD_INST(vkCreateAndroidSurfaceKHR);
        LOAD_INST(vkDestroySurfaceKHR);
        LOAD_INST(vkCreateDevice);
        LOAD_INST(vkDestroyDevice);
        LOAD_INST(vkGetDeviceQueue);
        LOAD_INST(vkDeviceWaitIdle);
        LOAD_INST(vkCreateSwapchainKHR);
        LOAD_INST(vkDestroySwapchainKHR);
        LOAD_INST(vkGetSwapchainImagesKHR);
        LOAD_INST(vkAcquireNextImageKHR);
        LOAD_INST(vkQueuePresentKHR);
        LOAD_INST(vkCreateCommandPool);
        LOAD_INST(vkDestroyCommandPool);
        LOAD_INST(vkAllocateCommandBuffers);
        LOAD_INST(vkResetCommandBuffer);
        LOAD_INST(vkBeginCommandBuffer);
        LOAD_INST(vkEndCommandBuffer);
        LOAD_INST(vkCmdPipelineBarrier);
        LOAD_INST(vkCmdClearColorImage);
        LOAD_INST(vkCreateSemaphore);
        LOAD_INST(vkDestroySemaphore);
        LOAD_INST(vkCreateFence);
        LOAD_INST(vkDestroyFence);
        LOAD_INST(vkWaitForFences);
        LOAD_INST(vkResetFences);
        LOAD_INST(vkQueueSubmit);
        #undef LOAD_INST
        return true;
    }

    bool selectPhysicalDevice() {
        uint32_t count = 0;
        vkEnumeratePhysicalDevices_(instance_, &count, nullptr);
        if (count == 0) return false;
        std::vector<VkPhysicalDevice> devices(count);
        vkEnumeratePhysicalDevices_(instance_, &count, devices.data());

        for (VkPhysicalDevice dev : devices) {
            uint32_t qCount = 0;
            vkGetPhysicalDeviceQueueFamilyProperties_(dev, &qCount, nullptr);
            std::vector<VkQueueFamilyProperties> queues(qCount);
            vkGetPhysicalDeviceQueueFamilyProperties_(dev, &qCount, queues.data());
            for (uint32_t i = 0; i < qCount; ++i) {
                VkBool32 presentSupport = VK_FALSE;
                vkGetPhysicalDeviceSurfaceSupportKHR_(dev, i, surface_, &presentSupport);
                if ((queues[i].queueFlags & VK_QUEUE_GRAPHICS_BIT) && presentSupport == VK_TRUE) {
                    physicalDevice_ = dev;
                    queueFamilyIndex_ = i;
                    return true;
                }
            }
        }
        return false;
    }

    bool createLogicalDevice() {
        float priority = 1.0f;
        VkDeviceQueueCreateInfo qci{};
        qci.sType = VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO;
        qci.queueFamilyIndex = queueFamilyIndex_;
        qci.queueCount = 1;
        qci.pQueuePriorities = &priority;

        const char* devExts[] = { VK_KHR_SWAPCHAIN_EXTENSION_NAME };
        VkDeviceCreateInfo dci{};
        dci.sType = VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO;
        dci.queueCreateInfoCount = 1;
        dci.pQueueCreateInfos = &qci;
        dci.enabledExtensionCount = 1;
        dci.ppEnabledExtensionNames = devExts;

        if (vkCreateDevice_(physicalDevice_, &dci, nullptr, &device_) != VK_SUCCESS) return false;
        vkGetDeviceQueue_(device_, queueFamilyIndex_, 0, &graphicsQueue_);
        return true;
    }

    bool createSwapchain(int32_t width, int32_t height) {
        VkSurfaceCapabilitiesKHR caps{};
        vkGetPhysicalDeviceSurfaceCapabilitiesKHR_(physicalDevice_, surface_, &caps);

        uint32_t fmtCount = 0;
        vkGetPhysicalDeviceSurfaceFormatsKHR_(physicalDevice_, surface_, &fmtCount, nullptr);
        if (fmtCount == 0) return false;
        std::vector<VkSurfaceFormatKHR> formats(fmtCount);
        vkGetPhysicalDeviceSurfaceFormatsKHR_(physicalDevice_, surface_, &fmtCount, formats.data());
        VkSurfaceFormatKHR chosenFmt = formats[0];
        for (const auto& f : formats) {
            if (f.format == VK_FORMAT_R8G8B8A8_UNORM) {
                chosenFmt = f;
                break;
            }
        }

        uint32_t modeCount = 0;
        vkGetPhysicalDeviceSurfacePresentModesKHR_(physicalDevice_, surface_, &modeCount, nullptr);
        std::vector<VkPresentModeKHR> modes(modeCount);
        if (modeCount > 0) {
            vkGetPhysicalDeviceSurfacePresentModesKHR_(physicalDevice_, surface_, &modeCount, modes.data());
        }
        VkPresentModeKHR chosenMode = VK_PRESENT_MODE_FIFO_KHR;
        if (!vsync_) {
            for (auto m : modes) {
                if (m == VK_PRESENT_MODE_MAILBOX_KHR || m == VK_PRESENT_MODE_IMMEDIATE_KHR) {
                    chosenMode = m;
                    break;
                }
            }
        }

        swapchainExtent_.width = std::clamp(static_cast<uint32_t>(width), caps.minImageExtent.width, caps.maxImageExtent.width);
        swapchainExtent_.height = std::clamp(static_cast<uint32_t>(height), caps.minImageExtent.height, caps.maxImageExtent.height);

        uint32_t imgCount = caps.minImageCount + 1;
        if (caps.maxImageCount > 0 && imgCount > caps.maxImageCount) imgCount = caps.maxImageCount;

        VkSwapchainCreateInfoKHR sci{};
        sci.sType = VK_STRUCTURE_TYPE_SWAPCHAIN_CREATE_INFO_KHR;
        sci.surface = surface_;
        sci.minImageCount = imgCount;
        sci.imageFormat = chosenFmt.format;
        sci.imageColorSpace = chosenFmt.colorSpace;
        sci.imageExtent = swapchainExtent_;
        sci.imageArrayLayers = 1;
        sci.imageUsage = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT | VK_IMAGE_USAGE_TRANSFER_DST_BIT;
        sci.imageSharingMode = VK_SHARING_MODE_EXCLUSIVE;
        sci.preTransform = caps.currentTransform;
        sci.compositeAlpha = VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR;
        sci.presentMode = chosenMode;
        sci.clipped = VK_TRUE;

        if (vkCreateSwapchainKHR_(device_, &sci, nullptr, &swapchain_) != VK_SUCCESS) return false;

        uint32_t actualImages = 0;
        vkGetSwapchainImagesKHR_(device_, swapchain_, &actualImages, nullptr);
        swapchainImages_.resize(actualImages);
        vkGetSwapchainImagesKHR_(device_, swapchain_, &actualImages, swapchainImages_.data());
        return true;
    }

    bool createSyncAndCommands() {
        VkCommandPoolCreateInfo pci{};
        pci.sType = VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO;
        pci.queueFamilyIndex = queueFamilyIndex_;
        pci.flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;
        if (vkCreateCommandPool_(device_, &pci, nullptr, &commandPool_) != VK_SUCCESS) return false;

        commandBuffers_.resize(swapchainImages_.size());
        VkCommandBufferAllocateInfo ai{};
        ai.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO;
        ai.commandPool = commandPool_;
        ai.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
        ai.commandBufferCount = static_cast<uint32_t>(commandBuffers_.size());
        if (vkAllocateCommandBuffers_(device_, &ai, commandBuffers_.data()) != VK_SUCCESS) return false;

        VkSemaphoreCreateInfo si{ VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO, nullptr, 0 };
        VkFenceCreateInfo fi{ VK_STRUCTURE_TYPE_FENCE_CREATE_INFO, nullptr, VK_FENCE_CREATE_SIGNALED_BIT };
        return vkCreateSemaphore_(device_, &si, nullptr, &imageAvailable_) == VK_SUCCESS &&
               vkCreateSemaphore_(device_, &si, nullptr, &renderFinished_) == VK_SUCCESS &&
               vkCreateFence_(device_, &fi, nullptr, &inFlightFence_) == VK_SUCCESS;
    }

    void destroySwapchain() {
        if (swapchain_ != VK_NULL_HANDLE && device_ != VK_NULL_HANDLE && vkDestroySwapchainKHR_) {
            vkDestroySwapchainKHR_(device_, swapchain_, nullptr);
            swapchain_ = VK_NULL_HANDLE;
        }
        swapchainImages_.clear();
    }

    void* vkLib_ = nullptr;
    ANativeWindow* window_ = nullptr;
    bool vsync_ = true;
    VkInstance instance_ = VK_NULL_HANDLE;
    VkSurfaceKHR surface_ = VK_NULL_HANDLE;
    VkPhysicalDevice physicalDevice_ = VK_NULL_HANDLE;
    uint32_t queueFamilyIndex_ = 0;
    VkDevice device_ = VK_NULL_HANDLE;
    VkQueue graphicsQueue_ = VK_NULL_HANDLE;
    VkSwapchainKHR swapchain_ = VK_NULL_HANDLE;
    VkExtent2D swapchainExtent_{0, 0};
    std::vector<VkImage> swapchainImages_;
    VkCommandPool commandPool_ = VK_NULL_HANDLE;
    std::vector<VkCommandBuffer> commandBuffers_;
    VkSemaphore imageAvailable_ = VK_NULL_HANDLE;
    VkSemaphore renderFinished_ = VK_NULL_HANDLE;
    VkFence inFlightFence_ = VK_NULL_HANDLE;

    PFN_vkGetInstanceProcAddr vkGetInstanceProcAddr_ = nullptr;
    PFN_vkCreateInstance vkCreateInstance_ = nullptr;
    PFN_vkDestroyInstance vkDestroyInstance_ = nullptr;
    PFN_vkEnumeratePhysicalDevices vkEnumeratePhysicalDevices_ = nullptr;
    PFN_vkGetPhysicalDeviceQueueFamilyProperties vkGetPhysicalDeviceQueueFamilyProperties_ = nullptr;
    PFN_vkGetPhysicalDeviceSurfaceSupportKHR vkGetPhysicalDeviceSurfaceSupportKHR_ = nullptr;
    PFN_vkGetPhysicalDeviceSurfaceCapabilitiesKHR vkGetPhysicalDeviceSurfaceCapabilitiesKHR_ = nullptr;
    PFN_vkGetPhysicalDeviceSurfaceFormatsKHR vkGetPhysicalDeviceSurfaceFormatsKHR_ = nullptr;
    PFN_vkGetPhysicalDeviceSurfacePresentModesKHR vkGetPhysicalDeviceSurfacePresentModesKHR_ = nullptr;
    PFN_vkCreateAndroidSurfaceKHR vkCreateAndroidSurfaceKHR_ = nullptr;
    PFN_vkDestroySurfaceKHR vkDestroySurfaceKHR_ = nullptr;
    PFN_vkCreateDevice vkCreateDevice_ = nullptr;
    PFN_vkDestroyDevice vkDestroyDevice_ = nullptr;
    PFN_vkGetDeviceQueue vkGetDeviceQueue_ = nullptr;
    PFN_vkDeviceWaitIdle vkDeviceWaitIdle_ = nullptr;
    PFN_vkCreateSwapchainKHR vkCreateSwapchainKHR_ = nullptr;
    PFN_vkDestroySwapchainKHR vkDestroySwapchainKHR_ = nullptr;
    PFN_vkGetSwapchainImagesKHR vkGetSwapchainImagesKHR_ = nullptr;
    PFN_vkAcquireNextImageKHR vkAcquireNextImageKHR_ = nullptr;
    PFN_vkQueuePresentKHR vkQueuePresentKHR_ = nullptr;
    PFN_vkCreateCommandPool vkCreateCommandPool_ = nullptr;
    PFN_vkDestroyCommandPool vkDestroyCommandPool_ = nullptr;
    PFN_vkAllocateCommandBuffers vkAllocateCommandBuffers_ = nullptr;
    PFN_vkResetCommandBuffer vkResetCommandBuffer_ = nullptr;
    PFN_vkBeginCommandBuffer vkBeginCommandBuffer_ = nullptr;
    PFN_vkEndCommandBuffer vkEndCommandBuffer_ = nullptr;
    PFN_vkCmdPipelineBarrier vkCmdPipelineBarrier_ = nullptr;
    PFN_vkCmdClearColorImage vkCmdClearColorImage_ = nullptr;
    PFN_vkCreateSemaphore vkCreateSemaphore_ = nullptr;
    PFN_vkDestroySemaphore vkDestroySemaphore_ = nullptr;
    PFN_vkCreateFence vkCreateFence_ = nullptr;
    PFN_vkDestroyFence vkDestroyFence_ = nullptr;
    PFN_vkWaitForFences vkWaitForFences_ = nullptr;
    PFN_vkResetFences vkResetFences_ = nullptr;
    PFN_vkQueueSubmit vkQueueSubmit_ = nullptr;
};

IRenderBackend* createVulkanBackend() {
    return new VulkanRenderBackend();
}

} // namespace nova
