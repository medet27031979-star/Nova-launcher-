package com.novalauncher.nativebridge

import android.view.Surface

data class NativeHardwareInfo(
    val cpuCoreCount: Int,
    val performanceCoreCount: Int,
    val totalRamMb: Long,
    val availableRamMb: Long,
    val socHardware: String,
    val glesVendor: String,
    val glesRenderer: String,
    val glesVersion: String,
    val gles32Supported: Boolean,
    val vulkanInstanceVerified: Boolean,
    val vulkanAndroidSurfaceSupported: Boolean,
    val vulkanDeviceName: String,
    val recommendedBackendOrdinal: Int,
    val recommendationReason: String
)

data class NativeTelemetry(
    val currentFps: Double,
    val frameTimeMs: Double,
    val avgFrameTimeMs: Double,
    val activeWidth: Int,
    val activeHeight: Int,
    val renderedFrames: Long,
    val poolAllocatedBytes: Long,
    val activeBackendOrdinal: Int
)

object NovaNativeEngine {
    init {
        System.loadLibrary("nova_native")
    }

    external fun nativeProbeHardware(): NativeHardwareInfo

    external fun nativeInitRenderer(
        surface: Surface,
        backendOrdinal: Int,
        width: Int,
        height: Int,
        resolutionScale: Float,
        vsync: Boolean,
        fpsLimit: Int
    ): Boolean

    external fun nativeResizeSurface(width: Int, height: Int)

    external fun nativeSetFpsLimit(fpsLimit: Int)

    external fun nativeSetVSync(enabled: Boolean)

    external fun nativeSetResolutionScale(scale: Float)

    external fun nativeRenderFrame(): Boolean

    external fun nativeGetTelemetry(): NativeTelemetry

    external fun nativeDestroyRenderer()

    external fun nativeLaunchJvm(
        libJvmPath: String,
        jvmArgs: Array<String>,
        mainClass: String,
        gameArgs: Array<String>
    ): Int
}
