package com.novalauncher.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.novalauncher.model.*
import com.novalauncher.ui.NovaUiState
import com.novalauncher.ui.NovaViewModel

@Composable
fun HomeScreen(state: NovaUiState, vm: NovaViewModel) {
    val activeProfile = state.profiles.firstOrNull { it.id == state.activeProfileId }
    val activeAccount = state.accounts.firstOrNull { it.id == state.activeAccountId }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Nova Launcher", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        state.statusBanner?.let {
            Text(it, color = MaterialTheme.colorScheme.secondary, style = MaterialTheme.typography.bodyMedium)
        }

        Surface(
            shape = MaterialTheme.shapes.medium,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Active Instance", style = MaterialTheme.typography.titleMedium)
                Text(
                    "${activeProfile?.name ?: "None"} · ${activeProfile?.mcVersion ?: "-"} · ${activeProfile?.loader?.displayName ?: "-"}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    "Account: ${activeAccount?.username ?: "None"} · RAM: ${activeProfile?.allocatedRamMb ?: 0} MB · Renderer: ${state.graphics.backend.displayName}",
                    style = MaterialTheme.typography.bodySmall,
                    fontFamily = FontFamily.Monospace
                )
                Button(
                    onClick = { vm.launchActiveProfile() },
                    enabled = !state.isLaunching && activeProfile != null
                ) {
                    Text(if (state.isLaunching) "Starting Runtime..." else "Launch Minecraft")
                }
            }
        }

        Surface(
            shape = MaterialTheme.shapes.medium,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Device Hardware Probe", style = MaterialTheme.typography.titleMedium)
                val hw = state.hardware
                if (hw == null) {
                    Text("Hardware probe pending or unavailable.")
                } else {
                    Text("SoC: ${hw.socHardware} (${hw.cpuCoreCount} cores, ${hw.performanceCoreCount} big)")
                    Text("GPU: ${hw.glesRenderer}")
                    Text("RAM: ${hw.availableRamMb} MB free / ${hw.totalRamMb} MB total", fontFamily = FontFamily.Monospace)
                    Text("Vulkan Verified: ${hw.vulkanInstanceVerified && hw.vulkanAndroidSurfaceSupported}")
                    Text(hw.recommendationReason, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
fun VersionsScreen(state: NovaUiState, vm: NovaViewModel) {
    var profileName by remember { mutableStateOf("Custom 1.21.4") }
    var selectedVersion by remember { mutableStateOf("1.21.4") }
    var selectedLoader by remember { mutableStateOf(ModLoaderType.FABRIC) }
    var ramMb by remember { mutableFloatStateOf(2048f) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Version & Loader Manager", style = MaterialTheme.typography.titleLarge)
            OutlinedTextField(
                value = profileName,
                onValueChange = { profileName = it },
                label = { Text("Profile Name") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ModLoaderType.entries.forEach { loader ->
                    FilterChip(
                        selected = selectedLoader == loader,
                        onClick = { selectedLoader = loader },
                        label = { Text(loader.displayName) }
                    )
                }
            }
            Text("RAM Allocation: ${ramMb.toInt()} MB", fontFamily = FontFamily.Monospace)
            Slider(value = ramMb, onValueChange = { ramMb = it }, valueRange = 1024f..4096f, steps = 5)
            Button(onClick = {
                if (profileName.isNotBlank()) {
                    vm.createProfile(profileName, selectedVersion, selectedLoader, ramMb.toInt())
                }
            }) {
                Text("Create Profile")
            }
        }

        items(state.profiles, key = { it.id }) { profile ->
            Surface(
                shape = MaterialTheme.shapes.small,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                onClick = { vm.selectProfile(profile.id) }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(profile.name, fontWeight = FontWeight.SemiBold)
                        Text("${profile.mcVersion} · ${profile.loader.displayName} · JRE ${profile.javaMajorVersion}")
                    }
                    Text("${profile.allocatedRamMb} MB", fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}

@Composable
fun ModsScreen(state: NovaUiState, vm: NovaViewModel) {
    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Mods, Resource Packs & Shaders", style = MaterialTheme.typography.titleLarge) }
        if (state.packs.isEmpty()) {
            item { Text("No mods or packs installed in active instance directory.") }
        } else {
            items(state.packs, key = { it.id }) { pack ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(pack.name, fontWeight = FontWeight.Medium)
                        Text("${pack.kind.name} · MC ${pack.targetMcVersion}")
                    }
                    Switch(checked = pack.enabled, onCheckedChange = { vm.togglePack(pack.id) })
                }
            }
        }
    }
}

@Composable
fun JavaRuntimeScreen(state: NovaUiState) {
    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Java Runtime Manager (ARM64)", style = MaterialTheme.typography.titleLarge) }
        items(state.runtimes, key = { it.id }) { rt ->
            Surface(shape = MaterialTheme.shapes.small, border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("Java ${rt.majorVersion} (${rt.vendor})", fontWeight = FontWeight.SemiBold)
                        Text("${rt.architecture} · ${rt.installPath}", style = MaterialTheme.typography.bodySmall)
                    }
                    Text(if (rt.isInstalled) "Installed" else "Not Installed")
                }
            }
        }
    }
}

@Composable
fun RendererSettingsScreen(state: NovaUiState, vm: NovaViewModel) {
    val vulkanAvailable = state.hardware?.let { it.vulkanInstanceVerified && it.vulkanAndroidSurfaceSupported } == true
    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Graphics & Renderer Settings", style = MaterialTheme.typography.titleLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = state.graphics.backend == RendererBackend.OPENGL_ES_32,
                onClick = { vm.updateGraphics { it.copy(backend = RendererBackend.OPENGL_ES_32) } },
                label = { Text("OpenGL ES 3.2") }
            )
            FilterChip(
                selected = state.graphics.backend == RendererBackend.VULKAN_1_1,
                enabled = vulkanAvailable,
                onClick = { vm.updateGraphics { it.copy(backend = RendererBackend.VULKAN_1_1) } },
                label = { Text(if (vulkanAvailable) "Vulkan 1.1+" else "Vulkan (Unsupported)") }
            )
        }

        Text("Resolution Scale: ${(state.graphics.resolutionScale * 100).toInt()}%", fontFamily = FontFamily.Monospace)
        Slider(
            value = state.graphics.resolutionScale,
            onValueChange = { v -> vm.updateGraphics { it.copy(resolutionScale = v) } },
            valueRange = 0.5f..1.0f
        )

        Text("FPS Limit: ${state.graphics.fpsLimit} FPS", fontFamily = FontFamily.Monospace)
        Slider(
            value = state.graphics.fpsLimit.toFloat(),
            onValueChange = { v -> vm.updateGraphics { it.copy(fpsLimit = v.toInt()) } },
            valueRange = 20f..120f
        )

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text("VSync (eglSwapInterval / FIFO)")
            Switch(
                checked = state.graphics.vsyncEnabled,
                onCheckedChange = { checked -> vm.updateGraphics { it.copy(vsyncEnabled = checked) } }
            )
        }
    }
}

@Composable
fun PerformanceDashboardScreen(state: NovaUiState, vm: NovaViewModel) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Performance & Thermal Engine", style = MaterialTheme.typography.titleLarge)
        val snap = state.thermalSnapshot
        Text("Thermal Status: ${snap?.thermalState?.label ?: "Unknown"} · Battery: ${snap?.batteryPercent ?: 100}%")
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text("Thermal & Battery Throttling")
            Switch(
                checked = state.performance.thermalAwareThrottling,
                onCheckedChange = { checked -> vm.updatePerformance { it.copy(thermalAwareThrottling = checked) } }
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text("Reduce Heap Allocations (AlwaysPreTouch)")
            Switch(
                checked = state.performance.reduceObjectAllocations,
                onCheckedChange = { checked -> vm.updatePerformance { it.copy(reduceObjectAllocations = checked) } }
            )
        }
    }
}

@Composable
fun ConsoleScreen(state: NovaUiState) {
    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        item { Text("Game & JNI Console", style = MaterialTheme.typography.titleLarge) }
        items(state.logs) { log ->
            Text(
                "[${log.level}/${log.tag}] ${log.message}",
                fontFamily = FontFamily.Monospace,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
fun DownloadsScreen(vm: NovaViewModel, state: NovaUiState) {
    val tasks by vm.downloadEngine.tasks.collectAsState()
    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Download Manager", style = MaterialTheme.typography.titleLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { vm.downloadEngine.startQueue(state.performance.maxConcurrentDownloads) }) { Text("Resume") }
                    TextButton(onClick = { vm.downloadEngine.pauseAll() }) { Text("Pause") }
                }
            }
        }
        if (tasks.isEmpty()) {
            item { Text("Download queue is idle.") }
        } else {
            items(tasks, key = { it.id }) { task ->
                Column {
                    Text("${task.title} · ${task.status.name}")
                    val pct = if (task.totalBytes > 0) task.downloadedBytes.toFloat() / task.totalBytes.toFloat() else 0f
                    LinearProgressIndicator(progress = { pct.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                }
            }
        }
    }
}

@Composable
fun AccountsScreen(state: NovaUiState, vm: NovaViewModel) {
    var username by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Account Management", style = MaterialTheme.typography.titleLarge)
        OutlinedTextField(
            value = username,
            onValueChange = { username = it; errorMsg = null },
            label = { Text("Offline Username (3-16 chars)") },
            modifier = Modifier.fillMaxWidth()
        )
        errorMsg?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Button(onClick = {
            errorMsg = vm.addOfflineAccount(username)
            if (errorMsg == null) username = ""
        }) {
            Text("Add Offline Profile")
        }

        state.accounts.forEach { acc ->
            Surface(
                shape = MaterialTheme.shapes.small,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                onClick = { vm.selectAccount(acc.id) }
            ) {
                Row(modifier = Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(acc.username, fontWeight = FontWeight.Medium)
                    Text(if (acc.id == state.activeAccountId) "Active" else acc.accountType.name)
                }
            }
        }
    }
}
