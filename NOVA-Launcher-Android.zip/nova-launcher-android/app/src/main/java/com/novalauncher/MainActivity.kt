package com.novalauncher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.novalauncher.ui.NovaViewModel
import com.novalauncher.ui.screens.*
import com.novalauncher.ui.theme.NovaTheme

private enum class LauncherTab(val label: String) {
    HOME("Home"),
    VERSIONS("Versions"),
    MODS("Mods"),
    JAVA("Java"),
    RENDERER("Renderer"),
    PERF("Perf"),
    CONSOLE("Console"),
    DOWNLOADS("Downloads"),
    ACCOUNTS("Accounts")
}

class MainActivity : ComponentActivity() {
    private val viewModel: NovaViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            NovaTheme {
                val state by viewModel.state.collectAsState()
                var currentTab by remember { mutableStateOf(LauncherTab.HOME) }

                Scaffold(
                    bottomBar = {
                        NavigationBar {
                            listOf(
                                LauncherTab.HOME to Icons.Default.Home,
                                LauncherTab.VERSIONS to Icons.Default.Layers,
                                LauncherTab.MODS to Icons.Default.Extension,
                                LauncherTab.RENDERER to Icons.Default.Tune,
                                LauncherTab.CONSOLE to Icons.Default.Terminal
                            ).forEach { (tab, icon) ->
                                NavigationBarItem(
                                    selected = currentTab == tab,
                                    onClick = { currentTab = tab },
                                    icon = { Icon(icon, contentDescription = tab.label) },
                                    label = { Text(tab.label) }
                                )
                            }
                        }
                    },
                    topBar = {
                        ScrollableTabRow(selectedTabIndex = currentTab.ordinal) {
                            LauncherTab.entries.forEach { tab ->
                                Tab(
                                    selected = currentTab == tab,
                                    onClick = { currentTab = tab },
                                    text = { Text(tab.label) }
                                )
                            }
                        }
                    }
                ) { padding ->
                    Box(modifier = Modifier.padding(padding)) {
                        when (currentTab) {
                            LauncherTab.HOME -> HomeScreen(state, viewModel)
                            LauncherTab.VERSIONS -> VersionsScreen(state, viewModel)
                            LauncherTab.MODS -> ModsScreen(state, viewModel)
                            LauncherTab.JAVA -> JavaRuntimeScreen(state)
                            LauncherTab.RENDERER -> RendererSettingsScreen(state, viewModel)
                            LauncherTab.PERF -> PerformanceDashboardScreen(state, viewModel)
                            LauncherTab.CONSOLE -> ConsoleScreen(state)
                            LauncherTab.DOWNLOADS -> DownloadsScreen(viewModel, state)
                            LauncherTab.ACCOUNTS -> AccountsScreen(state, viewModel)
                        }
                    }
                }
            }
        }
    }
}
