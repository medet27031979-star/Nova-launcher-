package com.novalauncher.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.novalauncher.auth.AccountManager
import com.novalauncher.engine.PerformanceEngine
import com.novalauncher.engine.ThermalAndBatterySnapshot
import com.novalauncher.model.*
import com.novalauncher.nativebridge.NativeHardwareInfo
import com.novalauncher.nativebridge.NovaNativeEngine
import com.novalauncher.network.DownloadEngine
import com.novalauncher.network.MojangManifestRepository
import com.novalauncher.network.MojangVersionSummary
import com.novalauncher.runtime.GameLaunchOrchestrator
import com.novalauncher.runtime.JavaRuntimeManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class NovaUiState(
    val hardware: NativeHardwareInfo? = null,
    val thermalSnapshot: ThermalAndBatterySnapshot? = null,
    val profiles: List<VersionProfile> = emptyList(),
    val activeProfileId: String = "",
    val mojangVersions: List<MojangVersionSummary> = emptyList(),
    val runtimes: List<JavaRuntimeInfo> = emptyList(),
    val packs: List<ContentPackItem> = emptyList(),
    val graphics: GraphicsConfig = GraphicsConfig(),
    val performance: PerformanceConfig = PerformanceConfig(),
    val accounts: List<AccountProfile> = emptyList(),
    val activeAccountId: String = "",
    val logs: List<ConsoleLogEntry> = emptyList(),
    val statusBanner: String? = null,
    val isLaunching: Boolean = false
)

class NovaViewModel(application: Application) : AndroidViewModel(application) {
    private val perfEngine = PerformanceEngine(application)
    private val runtimeManager = JavaRuntimeManager(application)
    private val manifestRepo = MojangManifestRepository()
    private val accountManager = AccountManager()
    val downloadEngine = DownloadEngine(viewModelScope)
    private val orchestrator = GameLaunchOrchestrator(application, runtimeManager, perfEngine)

    private val _state = MutableStateFlow(NovaUiState())
    val state: StateFlow<NovaUiState> = _state.asStateFlow()

    init {
        initializeEngine()
    }

    private fun initializeEngine() {
        val hw = runCatching { NovaNativeEngine.nativeProbeHardware() }.getOrNull()
        val thermal = perfEngine.sampleThermalAndBattery()
        val runtimes = runtimeManager.scanInstalledRuntimes()
        val recommended = hw?.let { perfEngine.recommendRenderer(it).first } ?: RendererBackend.OPENGL_ES_32

        val defaultProfile = VersionProfile(
            id = "fabric-1.21.4",
            name = "Survival Optimized",
            mcVersion = "1.21.4",
            loader = ModLoaderType.FABRIC,
            loaderVersion = "0.16.10",
            javaMajorVersion = 21,
            allocatedRamMb = hw?.let { perfEngine.computeSafeRamBudgetMb(it, 2048, thermal.thermalState) } ?: 1792
        )
        val defaultAccount = accountManager.createOfflineAccount("NovaPlayer").getOrThrow()

        _state.update {
            it.copy(
                hardware = hw,
                thermalSnapshot = thermal,
                runtimes = runtimes,
                profiles = listOf(defaultProfile),
                activeProfileId = defaultProfile.id,
                accounts = listOf(defaultAccount),
                activeAccountId = defaultAccount.id,
                graphics = it.graphics.copy(backend = recommended)
            )
        }
        appendLog("INFO", "NovaCore", "Hardware probe complete; recommended=${recommended.displayName}")
        refreshMojangManifest()
    }

    fun refreshMojangManifest() {
        viewModelScope.launch {
            manifestRepo.fetchVersionManifest()
                .onSuccess { resp ->
                    _state.update { it.copy(mojangVersions = resp.versions.take(30)) }
                    appendLog("INFO", "Manifest", "Fetched ${resp.versions.size} Mojang versions (latest ${resp.latest.release})")
                }
                .onFailure { err ->
                    appendLog("WARN", "Manifest", "Manifest fetch failed: ${err.message}")
                }
        }
    }

    fun selectProfile(id: String) {
        _state.update { it.copy(activeProfileId = id) }
    }

    fun createProfile(name: String, mcVersion: String, loader: ModLoaderType, ramMb: Int) {
        val hw = _state.value.hardware
        val thermal = _state.value.thermalSnapshot?.thermalState ?: ThermalState.NOMINAL
        val safeRam = if (hw != null) perfEngine.computeSafeRamBudgetMb(hw, ramMb, thermal) else ramMb
        val profile = VersionProfile(
            id = "${loader.name.lowercase()}-$mcVersion-${System.currentTimeMillis()}",
            name = name.trim(),
            mcVersion = mcVersion,
            loader = loader,
            loaderVersion = if (loader == ModLoaderType.VANILLA) "vanilla" else "latest",
            javaMajorVersion = runtimeManager.requiredJavaMajorForMc(mcVersion),
            allocatedRamMb = safeRam
        )
        _state.update {
            it.copy(profiles = it.profiles + profile, activeProfileId = profile.id)
        }
        appendLog("INFO", "Profiles", "Created profile '${profile.name}' (${profile.mcVersion} ${profile.loader.displayName})")
    }

    fun updateGraphics(transform: (GraphicsConfig) -> GraphicsConfig) {
        _state.update { it.copy(graphics = transform(it.graphics)) }
    }

    fun updatePerformance(transform: (PerformanceConfig) -> PerformanceConfig) {
        _state.update { it.copy(performance = transform(it.performance)) }
    }

    fun togglePack(packId: String) {
        _state.update { st ->
            st.copy(packs = st.packs.map { if (it.id == packId) it.copy(enabled = !it.enabled) else it })
        }
    }

    fun addOfflineAccount(username: String): String? {
        val res = accountManager.createOfflineAccount(username)
        return res.fold(
            onSuccess = { acc ->
                _state.update { st ->
                    st.copy(accounts = st.accounts + acc, activeAccountId = acc.id)
                }
                appendLog("INFO", "Auth", "Added offline profile '${acc.username}'")
                null
            },
            onFailure = { it.message }
        )
    }

    fun selectAccount(id: String) {
        _state.update { it.copy(activeAccountId = id) }
    }

    fun launchActiveProfile() {
        val st = _state.value
        val profile = st.profiles.firstOrNull { it.id == st.activeProfileId } ?: return
        val account = st.accounts.firstOrNull { it.id == st.activeAccountId } ?: return
        val hw = st.hardware ?: return

        viewModelScope.launch {
            _state.update { it.copy(isLaunching = true, statusBanner = "Launching ${profile.name}...") }
            orchestrator.prepareAndLaunch(
                profile = profile,
                account = account,
                hardware = hw,
                graphics = st.graphics,
                perf = st.performance,
                onLog = ::appendLog
            ).onFailure { err ->
                _state.update { it.copy(statusBanner = err.message) }
                appendLog("ERROR", "Launch", err.message ?: "Launch failed")
            }
            _state.update { it.copy(isLaunching = false) }
        }
    }

    fun appendLog(level: String, tag: String, message: String) {
        val entry = ConsoleLogEntry(System.currentTimeMillis(), level, tag, message)
        _state.update { st ->
            st.copy(logs = (st.logs + entry).takeLast(500))
        }
    }
}
