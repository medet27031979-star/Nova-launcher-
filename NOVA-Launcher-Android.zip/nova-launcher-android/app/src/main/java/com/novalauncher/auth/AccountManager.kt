package com.novalauncher.auth

import com.novalauncher.model.AccountProfile
import com.novalauncher.model.AccountType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import java.nio.charset.StandardCharsets
import java.util.UUID

@Serializable
data class DeviceCodeResponse(
    val user_code: String,
    val device_code: String,
    val verification_uri: String,
    val expires_in: Int,
    val interval: Int = 5
)

class AccountManager(
    private val microsoftClientId: String = ""
) {
    private val json = Json { ignoreUnknownKeys = true }
    private val client = OkHttpClient()

    fun createOfflineAccount(username: String): Result<AccountProfile> = runCatching {
        val trimmed = username.trim()
        require(trimmed.length in 3..16 && trimmed.matches(Regex("^[A-Za-z0-9_]+$"))) {
            "Username must be 3-16 characters (letters, numbers, underscores)."
        }
        val offlineUuid = UUID.nameUUIDFromBytes("OfflinePlayer:$trimmed".toByteArray(StandardCharsets.UTF_8)).toString()
        AccountProfile(
            id = "offline-$offlineUuid",
            username = trimmed,
            uuid = offlineUuid,
            accountType = AccountType.OFFLINE
        )
    }

    suspend fun requestMicrosoftDeviceCode(): Result<DeviceCodeResponse> = withContext(Dispatchers.IO) {
        runCatching {
            require(microsoftClientId.isNotBlank()) {
                "Configure your Azure App Client ID before initiating Microsoft OAuth."
            }
            val form = FormBody.Builder()
                .add("client_id", microsoftClientId)
                .add("scope", "XboxLive.signin offline_access")
                .build()
            val req = Request.Builder()
                .url("https://login.microsoftonline.com/consumers/oauth2/v2.0/devicecode")
                .post(form)
                .build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) error("Microsoft device code request failed (${resp.code})")
                val body = resp.body?.string() ?: error("Empty device code response")
                json.decodeFromString<DeviceCodeResponse>(body)
            }
        }
    }
}
