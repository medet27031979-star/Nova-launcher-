package com.novalauncher.engine

import com.novalauncher.model.AccountProfile
import com.novalauncher.model.AccountType
import com.novalauncher.model.GraphicsConfig
import com.novalauncher.model.PerformanceConfig
import com.novalauncher.model.RendererBackend
import com.novalauncher.model.VersionProfile
import java.io.File

object MinecraftArgumentBuilder {

    fun buildJvmArguments(
        profile: VersionProfile,
        safeRamMb: Int,
        graphics: GraphicsConfig,
        perf: PerformanceConfig,
        nativesDir: File,
        classpath: List<File>,
        loaderThreads: Int
    ): List<String> {
        val args = mutableListOf<String>()
        val xmsMb = (safeRamMb / 2).coerceAtLeast(512)
        args += "-Xms${xmsMb}M"
        args += "-Xmx${safeRamMb}M"

        when (perf.gcAlgorithm) {
            "ZGC" -> {
                if (profile.javaMajorVersion >= 17) {
                    args += "-XX:+UseZGC"
                } else {
                    args += "-XX:+UseG1GC"
                }
            }
            else -> {
                args += "-XX:+UseG1GC"
                args += "-XX:+ParallelRefProcEnabled"
                args += "-XX:MaxGCPauseMillis=35"
                args += "-XX:G1NewSizePercent=20"
                args += "-XX:G1ReservePercent=15"
            }
        }

        if (perf.reduceObjectAllocations) {
            args += "-XX:+AlwaysPreTouch"
            args += "-XX:+UnlockExperimentalVMOptions"
        }

        args += "-Djava.library.path=${nativesDir.absolutePath}"
        args += "-Dnova.renderer=${graphics.backend.name}"
        args += "-Dnova.resolution.scale=${graphics.resolutionScale}"
        args += "-Dnova.texture.capMb=${graphics.textureMemoryCapMb}"
        args += "-Dnova.mipmap.levels=${graphics.mipmapLevels}"
        args += "-Dnova.chunk.distance=${graphics.chunkRenderDistance}"
        args += "-Dnova.resource.threads=$loaderThreads"
        args += "-Dorg.lwjgl.opengl.libname=${if (graphics.backend == RendererBackend.VULKAN_1_1) "libnova_vk_gl.so" else "libGLESv3.so"}"

        if (profile.customJvmArgs.isNotBlank()) {
            profile.customJvmArgs.trim().split(Regex("\\s+")).forEach { token ->
                if (token.isNotBlank() && !token.startsWith("-Xmx") && !token.startsWith("-Xms")) {
                    args += token
                }
            }
        }

        if (classpath.isNotEmpty()) {
            args += "-Djava.class.path=${classpath.joinToString(":") { it.absolutePath }}"
        }
        return args
    }

    fun buildGameArguments(
        profile: VersionProfile,
        account: AccountProfile,
        gameDir: File,
        assetsDir: File,
        assetIndex: String
    ): List<String> {
        return listOf(
            "--username", account.username,
            "--version", profile.mcVersion,
            "--gameDir", gameDir.absolutePath,
            "--assetsDir", assetsDir.absolutePath,
            "--assetIndex", assetIndex,
            "--uuid", account.uuid,
            "--accessToken", account.accessToken.ifBlank { "0" },
            "--userType", if (account.accountType == AccountType.MICROSOFT) "msa" else "legacy",
            "--versionType", "Nova-${profile.loader.displayName}"
        )
    }
}
