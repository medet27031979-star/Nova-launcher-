package com.novalauncher.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val NovaDarkScheme = darkColorScheme(
    primary = Color(0xFF10B981),
    onPrimary = Color(0xFF042419),
    secondary = Color(0xFF38BDF8),
    background = Color(0xFF0B0F14),
    surface = Color(0xFF141A22),
    surfaceVariant = Color(0xFF1B232E),
    onBackground = Color(0xFFF1F5F9),
    onSurface = Color(0xFFE2E8F0),
    onSurfaceVariant = Color(0xFF94A3B8),
    outline = Color(0xFF283241),
    error = Color(0xFFEF4444)
)

@Composable
fun NovaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = NovaDarkScheme,
        content = content
    )
}
