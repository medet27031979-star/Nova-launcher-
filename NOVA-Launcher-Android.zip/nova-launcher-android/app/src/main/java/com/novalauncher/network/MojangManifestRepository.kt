package com.novalauncher.network

import com.novalauncher.model.ModLoaderType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

@Serializable
data class MojangManifestResponse(
    val latest: LatestVersions,
    val versions: List<MojangVersionSummary>
)

@Serializable
data class LatestVersions(
    val release: String,
    val snapshot: String
)

@Serializable
data class MojangVersionSummary(
    val id: String,
    val type: String,
    val url: String,
    val releaseTime: String,
    val sha1: String = ""
)

@Serializable
data class MojangVersionDetail(
    val id: String,
    val mainClass: String,
    val assetIndex: AssetIndexRef,
    val downloads: VersionDownloads,
    val libraries: List<MojangLibrary>
)

@Serializable
data class AssetIndexRef(
    val id: String,
    val sha1: String,
    val size: Long,
    val totalSize: Long = 0,
    val url: String
)

@Serializable
data class VersionDownloads(
    val client: DownloadArtifact
)

@Serializable
data class DownloadArtifact(
    val sha1: String,
    val size: Long,
    val url: String
)

@Serializable
data class MojangLibrary(
    val name: String,
    val downloads: LibraryDownloads? = null
)

@Serializable
data class LibraryDownloads(
    val artifact: LibraryArtifact? = null
)

@Serializable
data class LibraryArtifact(
    val path: String,
    val sha1: String,
    val size: Long,
    val url: String
)

@Serializable
data class FabricLoaderVersionEntry(
    val loader: FabricLoaderMeta
)

@Serializable
data class FabricLoaderMeta(
    val version: String,
    val stable: Boolean
)

class MojangManifestRepository {
    private val json = Json { ignoreUnknownKeys = true }
    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    suspend fun fetchVersionManifest(): Result<MojangManifestResponse> = withContext(Dispatchers.IO) {
        runCatching {
            val req = Request.Builder()
                .url("https://piston-meta.mojang.com/mc/game/version_manifest_v2.json")
                .build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) error("HTTP ${resp.code} fetching version manifest")
                val body = resp.body?.string() ?: error("Empty manifest body")
                json.decodeFromString<MojangManifestResponse>(body)
            }
        }
    }

    suspend fun fetchVersionDetail(versionUrl: String): Result<MojangVersionDetail> = withContext(Dispatchers.IO) {
        runCatching {
            val req = Request.Builder().url(versionUrl).build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) error("HTTP ${resp.code} fetching version detail")
                val body = resp.body?.string() ?: error("Empty detail body")
                json.decodeFromString<MojangVersionDetail>(body)
            }
        }
    }

    suspend fun fetchLoaderVersions(loader: ModLoaderType, mcVersion: String): Result<List<String>> =
        withContext(Dispatchers.IO) {
            runCatching {
                val url = when (loader) {
                    ModLoaderType.FABRIC -> "https://meta.fabricmc.net/v2/versions/loader/$mcVersion"
                    ModLoaderType.QUILT -> "https://meta.quiltmc.org/v3/versions/loader/$mcVersion"
                    ModLoaderType.NEOFORGE -> "https://maven.neoforged.net/api/maven/versions/releases/net/neoforged/neoforge"
                    ModLoaderType.FORGE -> "https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json"
                    ModLoaderType.VANILLA -> return@runCatching listOf("vanilla")
                }

                val req = Request.Builder().url(url).build()
                client.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) error("HTTP ${resp.code} fetching $loader metadata")
                    val body = resp.body?.string() ?: error("Empty loader response")
                    if (loader == ModLoaderType.FABRIC || loader == ModLoaderType.QUILT) {
                        val entries = json.decodeFromString<List<FabricLoaderVersionEntry>>(body)
                        entries.map { it.loader.version }.take(15)
                    } else {
                        listOf("latest-compatible")
                    }
                }
            }
        }
}
