package com.novalauncher

import android.os.Bundle
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import com.novalauncher.nativebridge.NovaNativeEngine
import java.util.concurrent.atomic.AtomicBoolean

class GameSurfaceActivity : ComponentActivity(), SurfaceHolder.Callback {

    private lateinit var hudText: TextView
    private val rendering = AtomicBoolean(false)
    private var renderThread: Thread? = null

    private var backendOrdinal = 0
    private var resolutionScale = 0.85f
    private var vsync = true
    private var fpsLimit = 60

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        backendOrdinal = intent.getIntExtra("backend_ordinal", 0)
        resolutionScale = intent.getFloatExtra("resolution_scale", 0.85f)
        vsync = intent.getBooleanExtra("vsync", true)
        fpsLimit = intent.getIntExtra("fps_limit", 60)

        val root = FrameLayout(this)
        val surfaceView = SurfaceView(this)
        surfaceView.holder.addCallback(this)

        hudText = TextView(this).apply {
            text = "Initializing Nova Surface..."
            setTextColor(0xFFE2E8F0.toInt())
            setBackgroundColor(0x990B0F14.toInt())
            setPadding(24, 14, 24, 14)
        }

        root.addView(surfaceView, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ))
        root.addView(hudText, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ))
        setContentView(root)
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        val frame = holder.surfaceFrame
        val ok = NovaNativeEngine.nativeInitRenderer(
            surface = holder.surface,
            backendOrdinal = backendOrdinal,
            width = frame.width().coerceAtLeast(1280),
            height = frame.height().coerceAtLeast(720),
            resolutionScale = resolutionScale,
            vsync = vsync,
            fpsLimit = fpsLimit
        )
        if (!ok) {
            hudText.text = "Renderer initialization failed"
            return
        }

        rendering.set(true)
        renderThread = Thread({
            var frameCounter = 0
            while (rendering.get()) {
                NovaNativeEngine.nativeRenderFrame()
                frameCounter++
                if (frameCounter % 20 == 0) {
                    val telemetry = NovaNativeEngine.nativeGetTelemetry()
                    runOnUiThread {
                        val api = if (telemetry.activeBackendOrdinal == 1) "Vulkan" else "GLES3.2"
                        hudText.text = "$api · ${"%.1f".format(telemetry.currentFps)} FPS (${"%.2f".format(telemetry.avgFrameTimeMs)} ms) · ${telemetry.activeWidth}x${telemetry.activeHeight}"
                    }
                }
            }
        }, "NovaRenderLoop").apply { start() }
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        NovaNativeEngine.nativeResizeSurface(width, height)
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        rendering.set(false)
        renderThread?.join(500)
        renderThread = null
        NovaNativeEngine.nativeDestroyRenderer()
    }
}
