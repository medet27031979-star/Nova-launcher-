package com.novalauncher.runtime

import android.content.Context
import android.content.Intent
import com.novalauncher.GameSurfaceActivity
import com.novalauncher.engine.MinecraftArgumentBuilder
import com.novalauncher.engine.PerformanceEngine
import com.novalauncher.model.AccountProfile
import com.novalauncher.model.GraphicsConfig
import com.novalauncher.model.PerformanceConfig
import com.novalauncher.model.VersionProfile
import com.novalauncher.nativebridge.NativeHardwareInfo
import com.novalauncher.nativebridge.NovaNativeEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class GameLaunchOrchestrator(
    private val context: Context,
    private val runtimeManager: JavaRuntimeManager,
    private val performanceEngine: PerformanceEngine
) {
    suspend fun prepareAndLaunch(
        profile: VersionProfile,
        account: AccountProfile,
        hardware: NativeHardwareInfo,
        graphics: GraphicsConfig,
        perf: PerformanceConfig,
        onLog: (level: String, tag: String, message: String) -> Unit
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val snapshot = performanceEngine.sampleThermalAndBattery()
            val adjustedGraphics = performanceEngine.applyThermalAndBatteryPolicy(graphics, perf, snapshot)
            val safeRamMb = performanceEngine.computeSafeRamBudgetMb(hardware, profile.allocatedRamMb, snapshot.thermalState)
            val loaderThreads = performanceEngine.recommendedResourceThreads(hardware, perf)

            onLog("INFO", "Perf", "Thermal=${snapshot.thermalState.label}, SafeRAM=${safeRamMb}MB, Threads=$loaderThreads")
            onLog("INFO", "Renderer", "Active backend=${adjustedGraphics.backend.displayName}, Scale=${adjustedGraphics.resolutionScale}, VSync=${adjustedGraphics.vsyncEnabled}")

            val runtimes = runtimeManager.scanInstalledRuntimes()
            val targetRuntime = runtimes.firstOrNull { it.majorVersion == profile.javaMajorVersion && it.isInstalled }
                ?: error("ARM64 JRE ${profile.javaMajorVersion} is not installed in filesDir/runtimes")

            val libJvm = runtimeManager.resolveLibJvm(File(targetRuntime.installPath))
                ?: error("libjvm.so missing inside ${targetRuntime.installPath}")

            val instanceDir = File(context.filesDir, "instances/${profile.id}").apply { mkdirs() }
            val nativesDir = File(instanceDir, "natives").apply { mkdirs() }
            val assetsDir = File(context.filesDir, "assets").apply { mkdirs() }
            val libsDir = File(context.filesDir, "libraries")
            val classpath = libsDir.walkTopDown().filter { it.extension == "jar" }.toList()

            val jvmArgs = MinecraftArgumentBuilder.buildJvmArguments(
                profile = profile,
                safeRamMb = safeRamMb,
                graphics = adjustedGraphics,
                perf = perf,
                nativesDir = nativesDir,
                classpath = classpath,
                loaderThreads = loaderThreads
            )
            val gameArgs = MinecraftArgumentBuilder.buildGameArguments(
                profile = profile,
                account = account,
                gameDir = instanceDir,
                assetsDir = assetsDir,
                assetIndex = profile.mcVersion.substringBeforeLast(".")
            )

            onLog("JNI", "Launcher", "Opening GameSurfaceActivity and binding native surface")
            val intent = Intent(context, GameSurfaceActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                putExtra("backend_ordinal", adjustedGraphics.backend.ordinalId)
                putExtra("resolution_scale", adjustedGraphics.resolutionScale)
                putExtra("vsync", adjustedGraphics.vsyncEnabled)
                putExtra("fps_limit", adjustedGraphics.fpsLimit)
            }
            context.startActivity(intent)

            val mainClassInternal = profile.loader.mainClass.replace('.', '/')
            val exitCode = NovaNativeEngine.nativeLaunchJvm(
                libJvmPath = libJvm.absolutePath,
                jvmArgs = jvmArgs.toTypedArray(),
                mainClass = mainClassInternal,
                gameArgs = gameArgs.toTypedArray()
            )
            if (exitCode != 0) {
                onLog("ERROR", "JVM", "Java process exited with code $exitCode")
                error("JVM exited with code $exitCode")
            }
            onLog("INFO", "JVM", "Game exited cleanly")
        }
    }
}
