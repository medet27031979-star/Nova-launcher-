package com.novalauncher.network

import com.novalauncher.model.DownloadStatus
import com.novalauncher.model.DownloadTask
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

class DownloadEngine(
    private val scope: CoroutineScope
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val _tasks = MutableStateFlow<List<DownloadTask>>(emptyList())
    val tasks: StateFlow<List<DownloadTask>> = _tasks.asStateFlow()

    private var activeJob: Job? = null

    fun enqueue(newTasks: List<DownloadTask>, maxConcurrency: Int) {
        _tasks.update { existing ->
            val map = existing.associateBy { it.id }.toMutableMap()
            newTasks.forEach { map[it.id] = it }
            map.values.toList()
        }
        startQueue(maxConcurrency)
    }

    fun startQueue(maxConcurrency: Int) {
        if (activeJob?.isActive == true) return
        val semaphore = Semaphore(maxConcurrency.coerceIn(1, 8))

        activeJob = scope.async(Dispatchers.IO) {
            coroutineScope {
                val pending = _tasks.value.filter {
                    it.status == DownloadStatus.QUEUED || it.status == DownloadStatus.FAILED
                }
                pending.map { task ->
                    async {
                        semaphore.withPermit {
                            executeSingleDownload(task)
                        }
                    }
                }.awaitAll()
            }
        }
    }

    fun pauseAll() {
        activeJob?.cancel()
        _tasks.update { list ->
            list.map {
                if (it.status == DownloadStatus.DOWNLOADING || it.status == DownloadStatus.QUEUED) {
                    it.copy(status = DownloadStatus.PAUSED)
                } else it
            }
        }
    }

    private fun executeSingleDownload(task: DownloadTask) {
        val target = File(task.destinationPath)
        target.parentFile?.mkdirs()

        if (target.exists() && task.expectedSha1.isNotBlank() && verifySha1(target, task.expectedSha1)) {
            updateTask(task.id) {
                it.copy(downloadedBytes = target.length(), status = DownloadStatus.COMPLETED)
            }
            return
        }

        updateTask(task.id) { it.copy(status = DownloadStatus.DOWNLOADING) }
        try {
            val req = Request.Builder().url(task.url).build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) error("HTTP ${resp.code}")
                val body = resp.body ?: error("Empty response body")
                val buffer = ByteArray(64 * 1024) // Reusable 64KB buffer to avoid GC churn
                var totalRead = 0L

                body.byteStream().use { input ->
                    FileOutputStream(target).use { output ->
                        while (true) {
                            val read = input.read(buffer)
                            if (read <= 0) break
                            output.write(buffer, 0, read)
                            totalRead += read
                            updateTask(task.id) { it.copy(downloadedBytes = totalRead) }
                        }
                    }
                }
            }

            updateTask(task.id) { it.copy(status = DownloadStatus.VERIFYING) }
            val valid = task.expectedSha1.isBlank() || verifySha1(target, task.expectedSha1)
            updateTask(task.id) {
                it.copy(status = if (valid) DownloadStatus.COMPLETED else DownloadStatus.FAILED)
            }
        } catch (_: Exception) {
            updateTask(task.id) { it.copy(status = DownloadStatus.FAILED) }
        }
    }

    private fun updateTask(id: String, transform: (DownloadTask) -> DownloadTask) {
        _tasks.update { list -> list.map { if (it.id == id) transform(it) else it } }
    }

    private fun verifySha1(file: File, expectedHex: String): Boolean {
        val digest = MessageDigest.getInstance("SHA-1")
        val buf = ByteArray(32 * 1024)
        FileInputStream(file).use { fis ->
            while (true) {
                val n = fis.read(buf)
                if (n <= 0) break
                digest.update(buf, 0, n)
            }
        }
        val actual = digest.digest().joinToString("") { "%02x".format(it) }
        return actual.equals(expectedHex, ignoreCase = true)
    }
}
