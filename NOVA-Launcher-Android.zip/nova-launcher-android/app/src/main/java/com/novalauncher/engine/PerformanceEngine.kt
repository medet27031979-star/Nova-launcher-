package com.novalauncher.engine

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import com.novalauncher.model.GraphicsConfig
import com.novalauncher.model.PerformanceConfig
import com.novalauncher.model.PowerMode
import com.novalauncher.model.RendererBackend
import com.novalauncher.model.ThermalState
import com.novalauncher.nativebridge.NativeHardwareInfo
import kotlin.math.max
import kotlin.math.min

data class ThermalAndBatterySnapshot(
    val thermalState: ThermalState,
    val batteryPercent: Int,
    val isCharging: Boolean,
    val isLowPowerMode: Boolean
)

class PerformanceEngine(private val context: Context) {

    fun sampleThermalAndBattery(): ThermalAndBatterySnapshot {
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val thermal = when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && powerManager != null -> {
                when (powerManager.currentThermalStatus) {
                    PowerManager.THERMAL_STATUS_NONE,
                    PowerManager.THERMAL_STATUS_LIGHT -> ThermalState.NOMINAL
                    PowerManager.THERMAL_STATUS_MODERATE -> ThermalState.MODERATE
                    PowerManager.THERMAL_STATUS_SEVERE -> ThermalState.SEVERE
                    else -> ThermalState.CRITICAL
                }
            }
            else -> ThermalState.NOMINAL
        }

        val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (level >= 0 && scale > 0) (level * 100) / scale else 100
        val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        val lowPower = powerManager?.isPowerSaveMode == true

        return ThermalAndBatterySnapshot(
            thermalState = thermal,
            batteryPercent = pct,
            isCharging = charging,
            isLowPowerMode = lowPower
        )
    }

    /**
     * Computes a safe JVM heap allocation (in MB) that preserves Android OS & SurfaceFlinger
     * headroom on 4 GB+ devices so LMKD (Low Memory Killer) never terminates the game process.
     */
    fun computeSafeRamBudgetMb(
        hardware: NativeHardwareInfo,
        requestedRamMb: Int,
        thermalState: ThermalState
    ): Int {
        val osReserveMb = if (hardware.totalRamMb <= 4608L) 1664 else 2048
        val hardCeilingMb = max(1024, (hardware.totalRamMb - osReserveMb).toInt())
        val thermalCapMb = when (thermalState) {
            ThermalState.CRITICAL -> min(hardCeilingMb, 1536)
            ThermalState.SEVERE -> min(hardCeilingMb, 2048)
            else -> hardCeilingMb
        }
        return requestedRamMb.coerceIn(768, thermalCapMb)
    }

    /**
     * Strictly recommends Vulkan only when the native C++ probe verified libvulkan.so,
     * vkCreateInstance, graphics queue support, and VK_KHR_android_surface.
     */
    fun recommendRenderer(hardware: NativeHardwareInfo): Pair<RendererBackend, String> {
        val vulkanVerified = hardware.vulkanInstanceVerified && hardware.vulkanAndroidSurfaceSupported
        return if (vulkanVerified && hardware.recommendedBackendOrdinal == RendererBackend.VULKAN_1_1.ordinalId) {
            RendererBackend.VULKAN_1_1 to hardware.recommendationReason
        } else {
            RendererBackend.OPENGL_ES_32 to hardware.recommendationReason
        }
    }

    fun applyThermalAndBatteryPolicy(
        graphics: GraphicsConfig,
        perf: PerformanceConfig,
        snapshot: ThermalAndBatterySnapshot
    ): GraphicsConfig {
        if (!perf.thermalAwareThrottling) return graphics

        val effectiveMode = if (snapshot.isLowPowerMode || (!snapshot.isCharging && snapshot.batteryPercent < 20)) {
            PowerMode.BATTERY_SAVER
        } else {
            perf.powerMode
        }

        return when {
            snapshot.thermalState == ThermalState.CRITICAL -> graphics.copy(
                fpsLimit = min(graphics.fpsLimit, 30),
                resolutionScale = min(graphics.resolutionScale, 0.65f),
                chunkRenderDistance = min(graphics.chunkRenderDistance, 5)
            )
            snapshot.thermalState == ThermalState.SEVERE || effectiveMode == PowerMode.BATTERY_SAVER -> graphics.copy(
                fpsLimit = min(graphics.fpsLimit, 45),
                resolutionScale = min(graphics.resolutionScale, 0.75f),
                chunkRenderDistance = min(graphics.chunkRenderDistance, 6)
            )
            else -> graphics
        }
    }

    fun recommendedResourceThreads(hardware: NativeHardwareInfo, perf: PerformanceConfig): Int {
        val maxSafe = max(2, min(hardware.performanceCoreCount, 6))
        return perf.resourceLoaderThreads.coerceIn(1, maxSafe)
    }
}
