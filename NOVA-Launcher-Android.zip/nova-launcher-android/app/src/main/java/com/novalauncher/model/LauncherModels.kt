package com.novalauncher.model

import kotlinx.serialization.Serializable

enum class RendererBackend(val ordinalId: Int, val displayName: String) {
    OPENGL_ES_32(0, "OpenGL ES 3.2"),
    VULKAN_1_1(1, "Vulkan 1.1+")
}

enum class ModLoaderType(val displayName: String, val mainClass: String) {
    VANILLA("Vanilla", "net.minecraft.client.main.Main"),
    FABRIC("Fabric", "net.fabricmc.loader.impl.launch.knot.KnotClient"),
    FORGE("Forge", "cpw.mods.bootstraplauncher.BootstrapLauncher"),
    NEOFORGE("NeoForge", "cpw.mods.bootstraplauncher.BootstrapLauncher"),
    QUILT("Quilt", "org.quiltmc.loader.impl.launch.knot.KnotClient")
}

enum class ThermalState(val label: String) {
    NOMINAL("Nominal"),
    MODERATE("Moderate"),
    SEVERE("Severe"),
    CRITICAL("Critical")
}

enum class PowerMode(val label: String) {
    BATTERY_SAVER("Battery Saver"),
    BALANCED("Balanced"),
    PERFORMANCE("High Performance")
}

enum class GraphicsProfile(
    val label: String,
    val resolutionScale: Float,
    val chunkDistance: Int,
    val mipmapLevels: Int,
    val textureCapMb: Int
) {
    ULTRA_LOW("Ultra Low (4GB)", 0.65f, 5, 1, 256),
    BALANCED("Balanced", 0.85f, 8, 2, 512),
    HIGH_FIDELITY("High Fidelity", 1.0f, 12, 4, 1024)
}

@Serializable
data class VersionProfile(
    val id: String,
    val name: String,
    val mcVersion: String,
    val loader: ModLoaderType,
    val loaderVersion: String,
    val javaMajorVersion: Int,
    val allocatedRamMb: Int,
    val customJvmArgs: String = "",
    val lastPlayedEpochMs: Long = 0L
)

@Serializable
data class GraphicsConfig(
    val backend: RendererBackend = RendererBackend.OPENGL_ES_32,
    val profile: GraphicsProfile = GraphicsProfile.BALANCED,
    val resolutionScale: Float = 0.85f,
    val fpsLimit: Int = 60,
    val vsyncEnabled: Boolean = true,
    val chunkRenderDistance: Int = 8,
    val textureMemoryCapMb: Int = 512,
    val mipmapLevels: Int = 2
)

@Serializable
data class PerformanceConfig(
    val powerMode: PowerMode = PowerMode.BALANCED,
    val thermalAwareThrottling: Boolean = true,
    val resourceLoaderThreads: Int = 4,
    val maxConcurrentDownloads: Int = 4,
    val gcAlgorithm: String = "G1GC",
    val reduceObjectAllocations: Boolean = true
)

@Serializable
data class JavaRuntimeInfo(
    val id: String,
    val majorVersion: Int,
    val vendor: String,
    val architecture: String,
    val installPath: String,
    val isInstalled: Boolean,
    val sizeMb: Int
)

@Serializable
data class ContentPackItem(
    val id: String,
    val name: String,
    val kind: PackKind,
    val targetMcVersion: String,
    val requiredLoader: ModLoaderType?,
    val requiresOpenGlCompat: Boolean = false,
    val enabled: Boolean = true,
    val sizeKb: Int = 0
)

enum class PackKind { MOD, RESOURCE_PACK, SHADER_PACK }

@Serializable
data class DownloadTask(
    val id: String,
    val title: String,
    val url: String,
    val destinationPath: String,
    val expectedSha1: String,
    val totalBytes: Long,
    val downloadedBytes: Long = 0L,
    val status: DownloadStatus = DownloadStatus.QUEUED
)

enum class DownloadStatus { QUEUED, DOWNLOADING, VERIFYING, COMPLETED, PAUSED, FAILED }

@Serializable
data class AccountProfile(
    val id: String,
    val username: String,
    val uuid: String,
    val accountType: AccountType,
    val accessToken: String = ""
)

enum class AccountType { MICROSOFT, OFFLINE }

data class ConsoleLogEntry(
    val timestampMs: Long,
    val level: String,
    val tag: String,
    val message: String
)
