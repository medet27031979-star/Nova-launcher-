package com.novalauncher.runtime

import android.content.Context
import com.novalauncher.model.JavaRuntimeInfo
import java.io.File

class JavaRuntimeManager(private val context: Context) {

    private val runtimesRoot: File
        get() = File(context.filesDir, "runtimes").apply { mkdirs() }

    fun scanInstalledRuntimes(): List<JavaRuntimeInfo> {
        val catalog = listOf(
            JavaRuntimeInfo("jre-8-arm64", 8, "Temurin ARM64", "arm64-v8a", File(runtimesRoot, "jre-8-arm64").absolutePath, false, 64),
            JavaRuntimeInfo("jre-17-arm64", 17, "Temurin ARM64", "arm64-v8a", File(runtimesRoot, "jre-17-arm64").absolutePath, false, 88),
            JavaRuntimeInfo("jre-21-arm64", 21, "Temurin ARM64", "arm64-v8a", File(runtimesRoot, "jre-21-arm64").absolutePath, false, 94)
        )

        return catalog.map { spec ->
            val dir = File(spec.installPath)
            val libJvm = resolveLibJvm(dir)
            val javaBin = File(dir, "bin/java")
            if (javaBin.exists() && !javaBin.canExecute()) {
                javaBin.setExecutable(true, true)
            }
            spec.copy(isInstalled = libJvm != null && libJvm.exists())
        }
    }

    fun resolveLibJvm(runtimeDir: File): File? {
        val candidates = listOf(
            File(runtimeDir, "lib/server/libjvm.so"),
            File(runtimeDir, "lib/aarch64/server/libjvm.so")
        )
        return candidates.firstOrNull { it.exists() }
    }

    fun requiredJavaMajorForMc(mcVersion: String): Int {
        val parts = mcVersion.split(".").mapNotNull { it.toIntOrNull() }
        val minor = parts.getOrNull(1) ?: 21
        val patch = parts.getOrNull(2) ?: 0
        return when {
            minor >= 21 || (minor == 20 && patch >= 5) -> 21
            minor >= 17 -> 17
            else -> 8
        }
    }
}
